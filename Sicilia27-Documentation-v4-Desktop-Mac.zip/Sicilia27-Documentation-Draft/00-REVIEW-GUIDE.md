# Sicilia27 — paquete documental para revisión

**Estado:** borrador revisado para Claude Desktop; no aplicar al repositorio hasta aprobación de Nacho.  
**Fecha de corte:** 15 de septiembre de 2026.
**Superficie prevista:** Claude Desktop para macOS, pestaña Code, plan Pro, sesión Local.

## Punto de entrada

`START_HERE.md` es la portada para Nacho y contiene el flujo gráfico y el prompt exacto de la primera sesión. `CLAUDE.md` es el archivo de instrucciones persistentes que Claude Code carga automáticamente. El primer contacto debe abrirse desde **Code → Local → selector Plan** y limitarse a leer, cuestionar y planificar; no autoriza ninguna modificación.

## Para qué existe este paquete

Estos archivos separan deliberadamente tres cosas que no deben confundirse:

1. **Prototipo actual:** evidencia de lo que ya existe en el repositorio de Google AI Studio.
2. **Intención de producto actualmente confirmada:** requisitos expresamente acordados con Nacho y estructura del RSVP mostrada en las diez capturas; Claude debe señalar cualquier contradicción antes de implementarla.
3. **Recomendaciones:** decisiones técnicas o de UX propuestas para implementar el producto con el menor trabajo innecesario posible.

Esta separación evita que Claude tome el prototipo, su contenido o su estética como especificación final.

## Orden de revisión recomendado

1. `PROJECT_BRIEF.md`: confirmar producto, alcance, restricciones y pendientes.
2. `docs/PRODUCT_AND_UX_SPEC.md`: validar flujos y reglas funcionales exactas.
3. `docs/ARCHITECTURE.md`: aceptar o cambiar la solución técnica propuesta.
4. `docs/DATA_MODEL.md`: validar qué datos se guardan y cómo se relacionan.
5. `docs/DEPLOYMENT_INTEGRATIONS_OPERATIONS.md`: revisar tiendas, PWA, Spotify, fotos, privacidad y operación.
6. `docs/OFFICIAL_SOURCE_MAP.md`: comprobar qué fuente respalda cada recomendación o restricción.
7. `docs/ROADMAP.md`: aceptar el orden de trabajo y sus criterios de salida.
8. `CLAUDE.md` y `.claude/rules/`: aprobar las instrucciones persistentes para Claude Code.
9. `docs/CLAUDE_DESKTOP_MAC_WORKFLOW.md`: validar el procedimiento operativo específico de Desktop.
10. Ejecutar la auditoría inicial descrita en `START_HERE.md`, todavía sin modificar archivos.

## Semántica utilizada

- **CONFIRMADO:** dicho o aceptado explícitamente por Nacho.
- **RECOMENDADO:** propuesta razonada, pendiente de aprobación final si cambia arquitectura o alcance.
- **TBD:** falta una decisión o dato real; Claude no debe inventarlo.
- **FUERA DE ALCANCE:** no construir salvo pedido posterior.

## Archivos incluidos

| Archivo | Función | Lógica de su contenido |
|---|---|---|
| `START_HERE.md` | Portada humana y primera sesión | Explica cómo iniciar Plan Mode y entrega un prompt breve de auditoría, sin sobrescribir el posible README del export. |
| `PROJECT_BRIEF.md` | Contexto principal de producto | Conserva la intención, objetivos y límites actuales; Claude debe auditarlo antes de proponer implementación. |
| `CLAUDE.md` | Instrucciones persistentes breves | Solo contiene reglas que Claude no puede inferir leyendo el código. |
| `.claude/rules/frontend.md` | Reglas condicionales de interfaz | Se carga al trabajar sobre TypeScript/React/CSS. |
| `.claude/rules/security.md` | Reglas de datos y secretos | Se aplica a cliente, funciones y configuración. |
| `.claude/rules/testing.md` | Evidencia mínima exigida | Obliga a verificar cambios antes de declararlos terminados. |
| `docs/PRODUCT_AND_UX_SPEC.md` | Especificación de flujos | Convierte las capturas y decisiones en estados y validaciones comprobables. |
| `docs/ARCHITECTURE.md` | Arquitectura y árbol propuesto | Mantiene una sola base React para PWA/nativo y separa el panel privado. |
| `docs/DATA_MODEL.md` | Modelo lógico de datos | Impide duplicados, estados ambiguos y RSVP incompletos. |
| `docs/DEPLOYMENT_INTEGRATIONS_OPERATIONS.md` | Integraciones y operación | Reúne decisiones que dependen de plataformas externas y revisión de tiendas. |
| `docs/OFFICIAL_SOURCE_MAP.md` | Trazabilidad documental | Mapea cada afirmación externa con la fuente oficial que la respalda. |
| `docs/ROADMAP.md` | Fases y puertas de calidad | Ordena por dependencias, no por semanas ficticias. |
| `docs/CLAUDE_DESKTOP_MAC_WORKFLOW.md` | Operación en Desktop Mac | Sustituye flags y hábitos del CLI por selectores, panes y revisiones de la app. |

## Decisiones aún abiertas

- Lugar definitivo del Día 1.
- Texto final, hora límite y fecha límite exacta del RSVP.
- Email organizador que recibirá cancelaciones.
- Contenido pre-evento del Home.
- Material definitivo de la agencia de viajes.
- Cuenta y tipo de cuenta de Google Play; alta de Apple Developer.
- Dominio definitivo del panel privado.
- Proveedor de correo y estrategia final de notificaciones.
- Destino y duración final de la galería aprobada.
- Plan de Supabase y validación final frente a la infraestructura IONOS disponible.

## Auditoría Claude Desktop realizada

| Archivo | Resultado de la revisión Desktop |
|---|---|
| `START_HERE.md` | Reescrito para Code tab, Local, selector Plan, Manual y Transcript Summary; evita colisionar con el README del export. |
| `CLAUDE.md` | Eliminados comandos npm presumidos; añadidos descubrimiento de scripts, ejecución autónoma en Desktop, Browser, Simulator y Diff. |
| `PROJECT_BRIEF.md` | Retirada la afirmación no verificada sobre lint/typecheck/build y corregida la referencia ambigua a “Desktop” como plataforma del invitado. |
| `docs/ARCHITECTURE.md` | El monorepo dejó de ser obligatorio; el export no se mueve hasta la auditoría en Plan. |
| `docs/DATA_MODEL.md` | Sin dependencia operativa de CLI; referencia de contenido adaptada a una ruta todavía pendiente de aprobación. |
| `docs/PRODUCT_AND_UX_SPEC.md` | Separadas comprobaciones Browser/Simulator y pruebas obligatorias en dispositivo real. |
| `docs/DEPLOYMENT_INTEGRATIONS_OPERATIONS.md` | Añadido entorno Claude Desktop Mac y verificaciones basadas en scripts reales. |
| `docs/OFFICIAL_SOURCE_MAP.md` | Añadida trazabilidad oficial específica de Desktop. |
| `docs/ROADMAP.md` | Flujo por fase convertido a Plan → aprobación → Manual → Browser/Simulator → Diff/Codex. |
| `.claude/rules/frontend.md` | Revisado: no contiene instrucciones dependientes del terminal; mantiene rutas actuales y candidatas. |
| `.claude/rules/security.md` | Revisado: no contiene instrucciones dependientes del terminal. |
| `.claude/rules/testing.md` | Adaptado a ejecución dentro de Desktop y descubrimiento previo de scripts. |
| `docs/CLAUDE_DESKTOP_MAC_WORKFLOW.md` | Nuevo procedimiento operativo específico para Nacho. |

## Por qué la documentación de Claude está dividida

Anthropic recomienda mantener `CLAUDE.md` corto, humano y reservado para instrucciones generales; las reglas específicas pueden vivir en `.claude/rules/` y limitarse por rutas para no consumir contexto siempre. También recomienda separar exploración, planificación e implementación y dar a Claude una verificación que pueda ejecutar. Por eso el brief detallado no se incrusta completo dentro de `CLAUDE.md`.

`START_HERE.md` no sustituye a `CLAUDE.md`: sirve como guía visible para la persona que abre el proyecto. Claude Desktop y CLI comparten `CLAUDE.md`, pero los controles de inicio no son equivalentes. El paquete usa el selector gráfico **Plan**, no flags o atajos del CLI. `AskUserQuestion` detiene el trabajo y solicita decisiones cuando existan varias interpretaciones o falte información.

### Fuentes oficiales de esta decisión documental

- [Anthropic — Best practices for Claude Code](https://code.claude.com/docs/en/best-practices)
- [Anthropic — How Claude remembers your project](https://code.claude.com/docs/en/memory)
- [Anthropic — Explore the `.claude` directory](https://code.claude.com/docs/en/claude-directory)
- [Anthropic — Claude Code Desktop](https://code.claude.com/docs/en/desktop)
- [Anthropic — Claude Code Desktop quickstart](https://code.claude.com/docs/en/desktop-quickstart)
- [Anthropic — Tools reference: `AskUserQuestion`](https://code.claude.com/docs/en/tools-reference)
- [Anthropic — Handle approvals and user input](https://code.claude.com/docs/en/agent-sdk/user-input)
- [Claude Academy](https://academy.claude.com/)
