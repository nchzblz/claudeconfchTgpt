# Sicilia27 — Start Here (Claude Desktop para Mac)

Este paquete combina dos tipos de material que deben revisarse antes de construir:

- El export de Google AI Studio es un prototipo funcional y visual; no es código ni diseño aprobado.
- Los documentos preparados con ChatGPT expresan la intención y las decisiones conocidas; tampoco sustituyen la revisión técnica de Claude.

`CLAUDE.md` contiene las instrucciones persistentes que Claude Code carga automáticamente. Este `START_HERE.md` es la portada humana para iniciar el proyecto de forma controlada en **Claude Desktop → Code**. No requiere usar Terminal.

## Primera sesión obligatoria

1. Actualizar Claude Desktop desde **Claude → Check for Updates**.
2. Abrir la pestaña **Code**.
3. Crear una sesión con **Environment: Local** y seleccionar la carpeta raíz `sicilia27/`, no una subcarpeta.
4. En el selector situado junto al botón de envío, elegir **Plan**. En Mac también puede abrirse ese selector con `Cmd + Shift + M`.
5. Opcional: seleccionar **Summary** en Transcript view para ocultar el detalle de herramientas y reducir ruido visual.
6. Pegar el prompt siguiente.
7. Mantener la sesión en **Plan** hasta aprobar expresamente el diagnóstico y el plan.

No usar `Shift + Tab`, `claude --permission-mode plan` ni otros flags del CLI: no corresponden al flujo de Claude Desktop.

## Prompt inicial

> Permanece exclusivamente en Plan Mode. No modifiques archivos, no escribas código, no instales dependencias y no ejecutes acciones externas.
>
> Confirma primero que reconoces las instrucciones de `CLAUDE.md` y que la carpeta seleccionada es la raíz del proyecto. Después lee este `START_HERE.md`, `PROJECT_BRIEF.md`, `00-REVIEW-GUIDE.md`, los archivos de `docs/` y las reglas relevantes de `.claude/rules/`. Finalmente inspecciona el export real de Google AI Studio y su configuración, sin ejecutar instalaciones ni modificar nada.
>
> Todo el material es una ayuda para comunicar la intención del proyecto y ahorrar tiempo, no una solución incuestionable. Evalúa críticamente tanto lo propuesto por ChatGPT como lo construido en Google AI Studio. No des por buena su arquitectura, código, UX, estética ni documentación.
>
> Identifica contradicciones, riesgos, información ausente, decisiones mejorables y elementos del prototipo que convenga conservar, corregir o reemplazar. Revisa también `CLAUDE.md` y propón mejoras sin aplicarlas.
>
> No supongas ni completes información. Si cualquier requisito o decisión material no está al menos 99% claro, utiliza `AskUserQuestion` y espera mi respuesta. Presenta como máximo tres preguntas relacionadas cada vez. Ningún `TBD` ni recomendación queda aprobado sin mi confirmación explícita.
>
> Mantén tus respuestas breves: máximo 10 puntos cortos, sin introducciones largas ni repetición de contexto. Primero realiza la entrevista y el diagnóstico; después presenta un plan por fases para mi aprobación. No implementes nada.

## Resultado esperado

La primera sesión termina únicamente cuando existen:

- un diagnóstico breve del material recibido;
- una lista de contradicciones y riesgos;
- las preguntas necesarias resueltas por Nacho;
- una propuesta de cambios para `CLAUDE.md`;
- un plan por fases pendiente de aprobación.

Después de aprobar el plan, cambiar el selector de **Plan** a **Manual**. Claude puede entonces implementar el primer corte aprobado; Nacho revisará cada diff dentro de Desktop. No es necesario ejecutar `/init`: la auditoría ya exige que Claude revise y proponga mejoras a `CLAUDE.md` sin aplicarlas automáticamente.

## Por qué está organizado así

Anthropic confirma que Desktop y CLI comparten el mismo motor, configuración y memoria `CLAUDE.md`, pero Desktop usa su propia interfaz gráfica para entorno, permisos, diffs, Browser y Simulator. También recomienda iniciar tareas complejas en Plan y pasar a Manual o Accept edits solo después de aprobar el plan. `AskUserQuestion` recopila requisitos y aclara ambigüedades. `START_HERE.md` es la guía visible para Nacho; no reemplaza `CLAUDE.md`.

### Fuentes oficiales de Anthropic

- [Best practices for Claude Code](https://code.claude.com/docs/en/best-practices)
- [Claude Code Desktop](https://code.claude.com/docs/en/desktop)
- [Claude Code Desktop quickstart](https://code.claude.com/docs/en/desktop-quickstart)
- [How Claude remembers your project](https://code.claude.com/docs/en/memory)
- [How Claude Code works](https://code.claude.com/docs/en/how-claude-code-works)
- [Tools reference — AskUserQuestion](https://code.claude.com/docs/en/tools-reference)
- [Handle approvals and user input](https://code.claude.com/docs/en/agent-sdk/user-input)
