# Implementation Roadmap

**Estado:** propuesta; organizada por dependencias y criterios de salida, no por semanas.  
**Meta externa:** invitaciones manuales el 1 de noviembre de 2026.  
**Principio:** una fase no está terminada por “verse bien”; debe producir evidencia ejecutable.

## Prioridad crítica inmediata

Antes de depender de publicación nativa:

1. Abrir/verificar Apple Developer y confirmar Google Play/tipo de cuenta.
2. Crear proyectos Supabase staging/production o cerrar formalmente la decisión IONOS.
3. Confirmar control de DNS para `sicilia2027.com`.
4. Congelar una hoja definitiva de 65 invitados sin incluirla en Git.
5. Definir Día 1, deadline RSVP y email organizador cuando estén disponibles.

Debido a que las cuentas y revisiones son externas, la PWA funcional es la ruta de contingencia obligatoria, no una tarea posterior.

## Fase 0 — Aprobación documental

### Entregables

- Brief, UX spec, arquitectura, modelo, operaciones y roadmap aprobados.
- Lista única de TBD.
- Decisión Supabase vs IONOS registrada como ADR.
- Contenido/prototipo marcado explícitamente como no final.

### Salida

- Nacho aprueba o corrige cada archivo.
- Desde Claude Desktop Code, sesión Local y selector Plan, Claude confirma que leyó el paquete y devuelve un plan sin modificar código.
- Claude presenta mediante `AskUserQuestion` cualquier contradicción, ausencia o decisión que no esté al menos 99% clara; no completa vacíos por su cuenta.
- Claude inspecciona el export real y propone mantener o cambiar la estructura; no mueve archivos por anticipado.

## Fase 1 — Base técnica reproducible

### Entregables

- Árbol existente auditado y estructura mínima aprobada.
- Guest app reorganizada solo donde exista una razón aprobada, sin migración especulativa a monorepo.
- Control app vacío pero autenticable.
- Staging y production separados.
- Gestor, runtime y scripts reales identificados desde la configuración existente.
- Migraciones iniciales, variables ejemplo y verificaciones de tipos/tests/build que el proyecto realmente defina o que Nacho apruebe añadir.
- Capacitor iOS/Android inicializado y PWA instalable.

### Salida

- Builds web/iOS/Android arrancan con datos ficticios.
- Ningún secreto o invitado real aparece en bundle/repositorio.
- Un estado versionado limpio reproduce instalación y todas las verificaciones aprobadas; Claude ejecuta los comandos desde Desktop.

## Fase 2 — Dominio RSVP y acceso seguro

### Entregables

- Modelo `invitations`, `event_days`, `rsvps`, `rsvp_days`, auditoría.
- Importador validado desde Sheet/CSV.
- Token exacto; inválido/revocado no filtra datos.
- Estados no iniciado/borrador/confirmado/cancelado.
- Guardado y reanudación de borrador.
- Submit idempotente y lock server-side.

### Salida

- Matriz automatizada cubre los tres días, +1 y tres rechazos.
- Dos dispositivos/retries no crean RSVP duplicados.
- Panel técnico muestra el mismo estado que la API.

## Fase 3 — RSVP UI final

### Entregables

- Dirección visual aprobada aparte con Claude y referencias visibles.
- Bienvenida animada rehecha.
- Pasos 1–8 conforme a `PRODUCT_AND_UX_SPEC.md`.
- Dietas/+1 separados; shuttle solo Día 3.
- Revisión/edición previa; confirmación visual sin QR ficticio.
- Mi RSVP mínimo + `.ics` personalizado.
- ES y en-US completos.

### Salida

- Recorrido web verificado en el Browser pane de Desktop; recorrido nativo iOS en Simulator cuando corresponda; pruebas físicas pendientes claramente marcadas.
- Checklist manual documentado confirma legibilidad, controles grandes y recuperación de errores sin exigir un piloto de invitados.
- Reduced motion, zoom, lector de pantalla, foco/error y target size verificados.

## Fase 4 — Spotify

### Entregables

- Función server-side con Client Credentials, secretos y rate limit.
- Búsqueda real, loading/error/empty, versiones y cover.
- Selección opcional 0–3 y persistencia de metadata.
- Atribución y enlace a Spotify.

### Salida

- Casos “Vogue — Madonna” muestran versiones distinguibles.
- Ningún secreto en cliente; no existe playback/playlist/datos ajenos.

## Fase 5 — Hub y contenido

### Entregables

- Tabs Home, RSVP, Programa, Travel.
- Content packages `es` y `en-US` editables.
- Itinerario, mapas y placeholders explícitos.
- Home pre-evento cuando el contenido sea aprobado.
- Cache de lectura/offline; escrituras exigen conexión.

### Salida

- Un cambio de lugar/hora/copy se hace en fuente canónica y se refleja donde corresponde.
- Confirmado entra directamente a Home; cancelado no entra.

## Fase 6 — Event Control Center

### Entregables

- Autenticación organizador.
- Invitaciones + WhatsApp manual + marcar enviado.
- Estados y totales RSVP.
- Restricciones, shuttle, canciones/mensajes.
- Export CSV/Google Sheets de una vía.
- Email de cancelación con outbox/reintentos.

### Salida

- Totales del panel concuerdan con consultas de DB y export.
- Admin no se incluye en binario guest.
- Fallos de correo/export quedan visibles y recuperables.

## Fase 7 — Distribución y contingencia

### Entregables

- PWA publicada en staging y luego production.
- Tutorial PWA iOS/Android probado.
- Universal Links/App Links verificados.
- Política de privacidad y declaraciones de tienda.
- Builds de tienda, metadata, demo token/QR y Review Notes.
- Solicitud Unlisted después de submit/review correspondiente.

### Salida

- WhatsApp de prueba abre ruta correcta instalada/no instalada.
- PWA puede recibir las invitaciones aunque una tienda no esté aprobada.
- Reviewer accede a todas las funciones documentadas.

## Fase 8 — Fotos Día 2

Puede desarrollarse después del lanzamiento RSVP, pero debe integrarse y probarse con suficiente margen antes de mayo.

### Entregables

- QR desbloquea upload por ventana.
- Consentimiento, cámara/galería, batches, optimización y progreso.
- Cuotas server-side y Storage privado.
- Panel de moderación con zoom y autor.
- Exports/backups de fotos.

### Salida

- 50/token, 10/lote y 3 MB se aplican bajo concurrencia/retry.
- Ninguna foto pending/rejected es visible al invitado.
- Restauración de muestra de objetos y metadata comprobada.

## Fase 9 — Galería final y cierre

### Entregables

- Decidir app vs web y retención.
- Galería solo aprobada, “by …”, zoom y descarga.
- Reporte/contacto/eliminación.
- Ocultar RSVP el 31 de mayo de 2027.
- Export final y plan de apagar servicios/app.

### Salida

- Política de retención ejecutable.
- Backups verificables antes de borrar cualquier proyecto.

## Matriz de dependencias

| Trabajo | Depende de | Puede avanzar en paralelo |
|---|---|---|
| UI RSVP final | Spec + dirección visual | Cuentas de tiendas. |
| Backend RSVP | Modelo + backend elegido | Diseño visual. |
| Spotify | Backend/secrets | Hub content. |
| Control Center | Backend RSVP | App-store metadata. |
| Fotos | Storage + tokens | Travel content. |
| Native release | Capacitor + cuentas + app funcional | PWA production. |
| Galería | Moderación + decisión de destino | Cierre RSVP. |

## Cómo debe trabajar Claude en cada fase

1. Abrir una sesión **Local** en Claude Desktop Code con la raíz del proyecto seleccionada.
2. Para cada tarea compleja, seleccionar **Plan**, explorar archivos y usar `AskUserQuestion` ante cualquier ambigüedad material.
3. Presentar plan y riesgos; esperar aprobación.
4. Cambiar a **Manual** para implementar únicamente el corte aprobado.
5. Inspeccionar scripts reales antes de ejecutar la prueba enfocada y las verificaciones completas disponibles.
6. Verificar web en Browser y iOS en Simulator cuando corresponda; señalar lo que requiere dispositivo físico.
7. Revisar Diff y usar Review code como control adicional antes de la revisión independiente de Codex.
8. Entregar evidencia, cambios, decisiones y pendientes en formato breve.

No usar una sesión enorme para todo el proyecto. Una fase o corte vertical por sesión conserva contexto y facilita revisión.

## Rol de Codex

- Revisar plan/diff y contradicciones con el brief.
- Ejecutar pruebas independientes y casos adversariales.
- Verificar citas/guías oficiales cuando haya decisiones de plataforma.
- Señalar deuda o riesgos concretos; no rediseñar silenciosamente lo aprobado.

## Lógica y fuentes

Las fases siguen dependencias técnicas: primero fuente de verdad y acceso, después interfaz persistente, luego contenido/integraciones y finalmente publicación/fotos. Las puertas de salida convierten la recomendación de Anthropic —dar a Claude una verificación y separar exploración, plan e implementación— en un proceso concreto. El canal PWA se adelanta porque las tiendas y verificaciones no son controlables por el equipo.

### Fuentes oficiales

- [Anthropic — Best practices for Claude Code](https://code.claude.com/docs/en/best-practices)
- [Anthropic — How Claude Code works](https://code.claude.com/docs/en/how-claude-code-works)
- [Anthropic — Claude Code memory and rules](https://code.claude.com/docs/en/memory)
- [Anthropic — Claude Code Desktop](https://code.claude.com/docs/en/desktop)
- [Claude Academy](https://academy.claude.com/)
- [Apple — Unlisted App Distribution](https://developer.apple.com/support/unlisted-app-distribution/)
- [Apple — App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Google Play — Testing requirements](https://support.google.com/googleplay/android-developer/answer/14151465)
- [Google Play — Prepare your app for review](https://support.google.com/googleplay/android-developer/answer/9859455)
