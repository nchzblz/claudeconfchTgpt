# Product & UX Specification

**Estado:** borrador para revisión.  
**Fuente funcional:** decisiones confirmadas con Nacho y capturas `Screen 1` a `Screen 10`.  
**Advertencia:** las capturas fijan la estructura del RSVP, no el diseño final.

## 1. Estados globales del invitado

| Estado | Pantalla inicial | Acceso permitido |
|---|---|---|
| Token inválido/ausente | Acceso no reconocido | Explicación + contacto por WhatsApp; ningún dato de invitado. |
| Invitación válida, RSVP sin iniciar | Bienvenida animada | Inicio del RSVP. |
| Borrador | Último paso completo o paso pendiente | Continuar RSVP; puede retroceder y corregir. |
| Confirmado | Home | Home, Mi RSVP, Programa, Travel; sin edición del RSVP. |
| Cancelado por rechazar los tres días | Confirmación de cancelación | Solo mensaje de cancelación y contacto por WhatsApp. |
| Después del 30 de mayo de 2027 | Home/archivo según decisión final | RSVP deja de mostrarse el 31 de mayo; datos permanecen hasta exportación/borrado manual. |

### Lógica

El estado debe venir del servidor, no de una bandera local. Esto evita que recargar, cambiar de dispositivo o reinstalar convierta un RSVP confirmado en editable o cree un duplicado.

## 2. Acceso mediante token

### Flujo

1. El invitado recibe manualmente un WhatsApp con enlace personal.
2. El enlace abre la app instalada mediante enlace universal/app link o, en su defecto, una página de descarga/PWA.
3. El servidor valida el token opaco.
4. Si es válido, devuelve solo el perfil autorizado: nombre, idioma, permiso de +1 y estado del RSVP.
5. El dispositivo conserva la sesión; el token se elimina de la URL visible tras el intercambio.
6. La app dirige al estado correcto de la tabla anterior.

### Reglas

- No permitir coincidencias por nombre ni tokens parciales.
- No usar un invitado de demostración como fallback.
- Un token representa una invitación, no dos cuentas por pareja.
- El +1 nunca recibe un flujo independiente.
- Un mismo token puede retomar el borrador; la restricción esencial es una sola confirmación por invitación.

## 3. Flujo RSVP actualmente confirmado

### Paso 0 — Bienvenida animada (`Screen 1`)

- Conservar el concepto de una entrada con vida y rehacer la ejecución visual.
- Botón claro para continuar; no obligar a esperar una animación larga.
- Con `prefers-reduced-motion`, reemplazar movimiento espacial por una transición breve de opacidad.

### Paso 1 — Introducción personalizada (`Screen 2`)

- Saludar por nombre y presentar los tres días.
- Mostrar que se responderá cada día por separado.
- Aparece solo en el primer ingreso al flujo, salvo que el usuario reinicie antes de confirmar.

### Pasos 2–4 — Días 1, 2 y 3 (`Screens 3–5`)

Cada día empieza con ambas decisiones **sin seleccionar**.

1. “¿Asistirás?” — Sí / No, obligatorio.
2. Si el titular responde Sí y tiene permiso de +1: “¿Asistirás con tu +1?” — Sí / No, obligatorio.
3. Si el titular responde No, ocultar/desactivar +1 y guardar `companion_attending = false`.
4. “Continuar” permanece deshabilitado hasta resolver las decisiones visibles.

No inferir que el +1 asistirá todos los días porque vaya a uno. La decisión es independiente por fecha.

### Caso excepcional — rechazar los tres días

Al intentar avanzar desde Día 3 con tres respuestas “No”:

1. Modal: “No has confirmado asistencia para ningún día, ¿es correcto?”
   - `Volver` → Día 1.
   - `Es correcto, no asistiré al evento` → segunda confirmación.
2. Segunda confirmación: “Al confirmar a continuación, se cancelará tu RSVP. ¿Deseas continuar?”
   - `Volver` → Día 1.
   - `Sí, cancela mi RSVP` → operación atómica de cancelación.
3. Guardar estado `cancelled`, fecha y respuestas negativas.
4. Enviar email al organizador: `{nombre} no asistirá y ha cancelado su RSVP`.
5. Limpiar sesión local y mostrar confirmación.
6. Accesos futuros con el token muestran el estado cancelado y el enlace de WhatsApp; no permiten entrar al Hub.

La doble confirmación es apropiada porque la acción revoca acceso y no puede corregirse desde la app.

### Paso 5 — Información adicional (`Screen 6`)

- Restricciones del titular: opcionales.
- Nombre del +1: opcional, solo si al menos un día incluye +1.
- Restricciones del +1: opcionales y separadas.
- Shuttle: solo Día 3 y solo si el titular asiste ese día. Definir en UI si la respuesta es para toda la invitación o por persona; el modelo propuesto lo guarda por invitación porque eso fue lo confirmado hasta ahora.
- No bloquear el avance por campos opcionales vacíos.

### Paso 6 — Canciones y mensaje (`Screen 7`)

- Ambos son opcionales y empiezan vacíos.
- Buscar el catálogo real de Spotify con *debounce* y estado de carga/error.
- Cada resultado muestra carátula original sin recorte, título, artista, álbum/versión y enlace a Spotify.
- Al seleccionar, guardar ID/URI, título, artistas, álbum, carátula y URL externa.
- Máximo tres selecciones. No reproducir, crear playlist ni mostrar elecciones ajenas.
- El mensaje personal es texto libre con un máximo técnico razonable definido antes de implementar (TBD; sugerencia: 1.000 caracteres).

### Paso 7 — Revisar antes de confirmar (`Screen 8`)

- Resumir los tres días, +1, restricciones, shuttle, canciones y mensaje.
- Cada bloque ofrece “Editar” y vuelve al paso correspondiente sin perder datos.
- Confirmar muestra una advertencia clara: después del envío no se podrá editar desde la app.
- El submit es idempotente: un doble toque, reintento de red o recarga no crea otra respuesta.

### Paso 8 — Confirmación (`Screen 9`)

- Reemplazar el QR/pase ficticio por una pieza visual elegante y no funcional.
- Mostrar únicamente:
  - días confirmados;
  - para cada día, si asistirá solo o con +1.
- No mostrar restricciones, shuttle, canciones ni mensaje.
- Acción “Agregar al calendario”: genera eventos solamente para los días confirmados.
- Acción de WhatsApp para pedir cambios; no hay edición en la app.

## 4. Hub posterior al RSVP (`Screen 10` como punto de partida)

### Navegación fija

1. Inicio / Home
2. RSVP
3. Programa / Itinerary
4. Travel

No reemplazar tabs durante el evento. La consistencia beneficia a invitados mayores.

### Home

- Contenido pre-evento: TBD.
- Puede mostrar cuenta regresiva, próximo hito y avisos operativos, pero no inventarlos antes de aprobación.
- El Día 2, tras desbloquear con el QR, aparece un acceso destacado a “Subir fotos”.

### RSVP

- Mismo resumen mínimo de la confirmación.
- Solo lectura.
- Desaparece de navegación el 31 de mayo de 2027.

### Programa / Itinerary

- Información canónica de los tres eventos, reescrita de forma breve para no repetir la invitación.
- Hora, lugar, indicaciones, vestimenta y botón a Google Maps.
- El lugar del Día 1 permanece claramente marcado como TBD en datos, no inventado en copy.

### Travel

- Categorías iniciales: Noto, Sicilia, Europa y logística/viaje.
- Contenido general + enlaces externos + material de la agencia.
- Español e inglés estadounidense se editan como dos versiones editoriales relacionadas.

## 5. Fotos del Día 2

### Desbloqueo

1. Antes del evento no se muestra la función.
2. El invitado escanea un QR físico en las mesas.
3. El enlace valida un secreto de evento y un token/sesión de invitado.
4. El permiso de carga se guarda para esa invitación hasta el fin de la ventana del evento.
5. Home muestra “Subir fotos”; también se abre directamente la pantalla de carga.

### Primera carga

- Consentimiento breve: las fotos se atribuirán al invitado, serán revisadas antes de publicarse y puede solicitar su eliminación por email/WhatsApp.
- Acciones: “Tomar foto” y “Elegir de la galería”.
- Solicitar permiso de cámara/fotos solo al tocar la acción correspondiente.

### Límites y estados

- Solo JPEG, PNG o HEIC/HEIF si la canalización puede normalizarlo con fiabilidad; compatibilidad final TBD mediante prueba real iOS/Android.
- 10 fotos por lote; 50 por token en total.
- Máximo final 3 MB por archivo.
- Si supera 3 MB, optimizar progresivamente sin reducir dimensiones salvo que sea necesario; objetivo operativo de 3.500–4.500 px en el lado largo si hace falta reducir.
- Mostrar progreso individual, éxito, error recuperable y contador restante.
- El servidor vuelve a validar tipo, tamaño, cantidad y permiso; la validación del navegador no basta.
- Estado inicial `pending`; solo el panel puede cambiar a `approved` o `rejected`.
- Hasta aprobación, ningún invitado obtiene una URL visible.

### Moderación y galería final

- Panel: miniatura, ampliación/zoom, autor, fecha, aprobar y rechazar.
- Galería final: solo `approved`, atribución “by …”, ampliación y descarga.
- Para cumplir la moderación de contenido generado por usuarios si se publica en iOS: filtro previo, canal de reporte/contacto y capacidad de revocar al autor/token.

## 6. Instalación PWA guiada

### iOS

- La web puede oscurecer y bloquear su propia interfaz, destacar visualmente dónde está Compartir y animar un cursor pedagógico.
- Antes de abrir el menú nativo, mostrar una simulación exacta del siguiente paso: Compartir → “Agregar a pantalla de inicio” → “Abrir como app”.
- No afirmar ni intentar que la web controla el cursor, resalta o bloquea la hoja nativa de Compartir.
- Tras detectar ejecución en modo `standalone`, no volver a mostrar el tutorial.
- Incluir “Necesito ayuda” y salida accesible para no atrapar al usuario si su versión de iOS difiere.

### Android/navegadores compatibles

- Usar el evento `beforeinstallprompt` cuando exista.
- Si no existe, mostrar instrucciones del navegador; no presentar un botón falso de instalación.

## 7. Accesibilidad y personas mayores

- Objetivo mínimo: WCAG 2.2 AA para la PWA y equivalencia funcional en nativo.
- Targets mínimos de 24×24 CSS px exigidos por WCAG; **recomendación del proyecto: 44×44** siempre que sea posible, por mayor tolerancia al toque.
- Texto ampliable, contraste comprobado, etiquetas visibles, mensajes de error junto al campo y foco enviado al error.
- No usar gestos ocultos ni depender de arrastrar.
- No comunicar asistencia, error o aprobación solo por color.
- Animaciones pausables/reducibles; nada debe impedir completar el RSVP.
- Probar VoiceOver/TalkBack y zoom/reflow en dispositivo real; las capturas no demuestran accesibilidad completa.

## 8. Criterios de aceptación por riesgo

| Riesgo | Evidencia requerida |
|---|---|
| Token filtra otro invitado | Pruebas de token inválido, manipulado y revocado; respuesta sin PII. |
| RSVP incompleto | Matriz de los tres días con/sin +1 y elecciones no respondidas. |
| Duplicado | Doble toque, retry y dos pestañas producen una sola confirmación. |
| Confirmado editable | API rechaza mutación aunque se manipule el cliente. |
| Cancelación accidental | Dos confirmaciones, vuelta a Día 1 y notificación auditada. |
| Foto privada visible | URL anónima y usuario no autorizado fallan; aprobada funciona por ruta permitida. |
| Tutorial PWA engañoso | Puede prepararse en Browser, pero exige prueba final en Safari iOS real; el copy no promete control del menú nativo. |
| UX de mayores | Primera comprobación en Browser/Simulator de Desktop y recorrido final documentado en dispositivo real con texto ampliado, targets grandes, foco, errores y lector de pantalla; no exige un grupo piloto de invitados. |

## 9. Lógica y fuentes

La especificación usa estados explícitos y validación redundante cliente/servidor porque la interfaz puede fallar, recargarse o manipularse. El contenido generado por usuarios permanece privado hasta moderación para cumplir el producto confirmado y reducir el riesgo de publicación. El tutorial PWA distingue la interfaz web de la UI nativa porque iOS documenta el flujo manual y no soporta `beforeinstallprompt`.

### Fuentes oficiales

- [Apple — Turn a website into an app in Safari on iPhone](https://support.apple.com/guide/iphone/iphea86e5236/ios)
- [MDN — Making PWAs installable (`beforeinstallprompt` no está soportado en iOS)](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable)
- [Apple — App Review Guidelines, 1.2 User-Generated Content](https://developer.apple.com/app-store/review/guidelines/#user-generated-content)
- [Apple — App Review Guidelines, 5.1 Privacy](https://developer.apple.com/app-store/review/guidelines/#privacy)
- [W3C — WCAG 2.2](https://www.w3.org/TR/WCAG22/)
- [W3C — Target Size (Minimum)](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum)
- [W3C — Animation from Interactions](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions)
- [Spotify — Search for Item](https://developer.spotify.com/documentation/web-api/reference/search)
- [Spotify — Track metadata and attribution requirements](https://developer.spotify.com/documentation/web-api/reference/get-track)
- [RFC Editor — RFC 5545 iCalendar](https://www.rfc-editor.org/rfc/rfc5545)
- [Anthropic — Claude Code Desktop: Browser and iOS Simulator](https://code.claude.com/docs/en/desktop)
