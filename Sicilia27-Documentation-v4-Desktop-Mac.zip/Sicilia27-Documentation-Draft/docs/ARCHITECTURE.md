# Architecture Proposal

**Estado:** hipótesis para auditoría en Plan Mode; no aprobada ni implementada.  
**Superficie de trabajo:** Claude Desktop para macOS, pestaña Code, sesión Local.  
**Objetivo:** encontrar la solución más simple que cubra iOS, Android, PWA, RSVP persistente, panel privado, Spotify y fotos sin reorganizar el export antes de entenderlo.

## Hipótesis técnica a validar

La opción inicial sigue siendo conservar React + TypeScript + Vite, añadir Capacitor para iOS/Android y usar Supabase para Postgres, Storage, funciones y autenticación del panel. Sin embargo, Claude debe contrastarla con el export real, versiones, dependencias, scripts y limitaciones antes de recomendarla. Nacho debe aprobar la arquitectura después de esa auditoría.

### Por qué

- Capacitor está diseñado para añadir contenedores nativos a una aplicación web existente y mantener versión web/PWA.
- El equipo operativo es una persona con ayuda de Claude/Codex; una base compartida reduce duplicación.
- Supabase reúne persistencia, políticas de acceso, Storage, funciones y backups; evita construir y mantener desde cero una API PHP, sesiones, subida segura y panel de datos.
- El volumen es pequeño: 65 invitaciones y un máximo teórico de 9,75 GB de fotos (`65 × 50 × 3 MB`). La escala no justifica microservicios.
- El panel no debe incluirse en el binario de invitados; separarlo reduce superficie y confusión de revisión.

Esta es una inferencia de ingeniería basada en requisitos y documentación oficial, no una obligación de plataforma. Antes de contratar un plan se debe comparar el plan Supabase vigente con la cuenta IONOS real.

### Puerta previa obligatoria

En la primera sesión Desktop, Claude permanece en Plan Mode y debe:

1. inspeccionar la raíz real, `package.json`, lockfile, configuración Vite/PWA, dependencias y estructura actual;
2. identificar qué partes son funcionales, simuladas, inseguras o prescindibles;
3. comparar la hipótesis React/Vite + Capacitor + Supabase con alternativas viables;
4. proponer la mínima reorganización necesaria y sus costes;
5. preguntar mediante `AskUserQuestion` cualquier decisión que no esté al menos 99 % clara;
6. esperar aprobación antes de mover archivos, instalar paquetes o inicializar servicios.

## Vista de componentes

```mermaid
flowchart TD
    G["Guest app<br/>React + Capacitor/PWA"] --> E["Server functions<br/>token validation + business rules"]
    C["Event Control Center<br/>web only"] --> E
    E --> D["Postgres<br/>RSVP + status + audit"]
    E --> S["Private Storage<br/>pending photos"]
    E --> X["Spotify / email / exports"]
```

## Estructura de entrada para la auditoría

```text
sicilia27/
├── CLAUDE.md
├── START_HERE.md
├── 00-REVIEW-GUIDE.md
├── .claude/
│   └── rules/
│       ├── frontend.md
│       ├── security.md
│       └── testing.md
├── docs/
└── [export real de Google AI Studio conservado en sus rutas actuales, incluido su README si existe]
```

No colocar una segunda copia navegable del código dentro de la misma raíz: duplicaría resultados de búsqueda y podría hacer que Claude edite la copia equivocada. Antes de trabajar, conservar el export original mediante un ZIP externo a la raíz o un commit inicial, únicamente después de que Nacho apruebe esa acción.

## Estructura candidata después de la auditoría

La opción de menor cambio es mantener la aplicación guest en la estructura actual del export y añadir carpetas solo cuando exista una necesidad aprobada:

```text
sicilia27/
├── src/                              # guest app actual, reorganizada gradualmente
│   ├── features/                     # access, rsvp, hub, songs, photos
│   ├── content/                      # es y en-US
│   ├── domain/                       # estados y validaciones puras
│   ├── platform/                     # adaptadores web/nativo
│   └── components/
├── control/                          # panel web separado, cuando se implemente
├── supabase/                         # solo si se aprueba Supabase
├── tests/
├── ios/                              # solo después de aprobar Capacitor
├── android/                          # solo después de aprobar Capacitor
└── configuración existente verificada
```

Un monorepo `apps/ + packages/` queda como evolución posible, no como punto de partida. Claude solo debe proponerlo si demuestra que compartir código entre guest/control compensa el coste de mover el export y cambiar sus herramientas.

### Lógica de la estructura candidata

- Mantener inicialmente el guest app donde ya funciona reduce cambios de configuración no relacionados con el producto.
- `control/` conserva el panel fuera del build de invitados sin imponer workspaces antes de necesitarlos.
- `src/domain` concentra reglas que deben coincidir en UI, servidor y pruebas.
- `src/content` permite editar textos/fechas sin buscar dentro de componentes.
- `platform` encapsula diferencias: cámara, enlaces, notificaciones, almacenamiento seguro y PWA.
- `supabase/migrations` vuelve reproducible el esquema; editar tablas manualmente sin migración crea estados imposibles de auditar.
- La organización final de tests debe seguir primero las convenciones existentes del export; no se mueve por estética.

No se recomienda migrar todo de una vez. Primero se extraen dominio/contenido, después acceso/persistencia y finalmente las aplicaciones.

## Fronteras de seguridad

### Invitado

- El cliente recibe configuración publicable, nunca claves secretas.
- Todas las operaciones de invitado pasan por funciones de servidor que validan token/sesión y aplican reglas.
- No se permite acceso directo de invitado a tablas administrativas.
- El token se trata como credencial; se borra de la URL visible después de conservarlo de forma apropiada para la plataforma.

### Panel

- Autenticación separada para organizadores.
- RLS y funciones administrativas; mínimo privilegio.
- Registro de cambios de RSVP, invitaciones y moderación.
- No se considera seguro un panel solo porque su URL no sea pública.

### Secretos

- `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`, credenciales de email y clave secreta de Supabase viven en secretos de funciones/hosting.
- `.env.example` contiene solo nombres y valores ficticios.
- Las claves secretas de Supabase no van al navegador, aplicación compilada ni repositorio porque omiten RLS.

## Diseño del acceso por token

### Recomendación

Usar un token aleatorio de alta entropía por invitación, validado solo en servidor. Guardar un derivado no reversible para validación; si el panel debe reconstruir el enlace para reenvío, mantener el valor recuperable únicamente cifrado y accesible desde función administrativa, o rotarlo y generar un enlace nuevo.

El detalle hash+cifrado debe resolverse antes de importar invitados; no guardar tokens legibles en la tabla consultable por el cliente.

### Ciclo

1. El enlace entrega el token una vez.
2. Función `claim-invitation` valida estado y obtiene la invitación.
3. Se establece una sesión limitada a esa invitación.
4. `history.replaceState` elimina el token de la URL web.
5. Cada función deriva `invitation_id` de la sesión, nunca de un ID libre enviado por el cliente.

## Persistencia e idempotencia

- Una fila `rsvps` por invitación, con estados `not_started`, `draft`, `confirmed`, `cancelled`.
- Una fila por día en `rsvp_days`, con restricción única `(rsvp_id, event_day_id)`.
- Guardado de borrador mediante *upsert* controlado.
- Confirmación y cancelación como transacciones; fecha y versión de revisión.
- Después de `confirmed` o `cancelled`, la API rechaza cambios de invitado.
- Clave idempotente en submit para que retries no creen eventos/correos duplicados.

## Offline

**RECOMENDADO:** cachear shell, contenido editorial e itinerario para lectura. No aceptar RSVP, cancelación o fotos como exitosos sin confirmación del servidor. Si no hay conexión, conservar el formulario local como borrador temporal y sincronizar explícitamente cuando vuelva la red.

Esto mantiene utilidad básica sin introducir una compleja cola de conflictos para 65 usuarios.

## IONOS como alternativa

React no requiere cambio si la base está en IONOS. La misma app puede consumir una API PHP/REST y usar MySQL/almacenamiento allí. Elegir IONOS implicaría implementar y operar explícitamente:

- sesiones/token exchange;
- autorización por recurso;
- migraciones y backups;
- subida validada y URLs privadas;
- procesamiento de imágenes;
- panel y exportación;
- rate limiting, logs y correo.

**Puerta de decisión:** confirmar plan, versiones disponibles, almacenamiento, límites de ejecución, backups y credenciales IONOS. Cambiar a IONOS solo si su ventaja real de coste/control supera el trabajo adicional demostrado.

## ADR resumidas

| ID | Decisión | Estado | Motivo |
|---|---|---|---|
| ADR-001 | React/Vite + Capacitor + PWA | Recomendada | Un código y acceso nativo cuando haga falta. |
| ADR-002 | Supabase como backend operativo | Recomendada | Menos infraestructura propia; RLS, Storage y backups integrados. |
| ADR-003 | Panel web separado del guest app | Recomendada | No enviar superficie administrativa en el binario. |
| ADR-004 | Contenido bilingüe versionado en archivos | Confirmada | Edición con Claude/Codex, sin CMS. |
| ADR-005 | Operaciones de invitado solo por funciones | Recomendada | Token no equivale a acceso directo general a DB. |
| ADR-006 | Lectura offline, escrituras online | Recomendada | Evita conflictos y falsos éxitos. |
| ADR-007 | Mantener estructura actual antes de auditar | Recomendada | Evita una migración de carpetas especulativa. |
| ADR-008 | Monorepo `apps/packages` | Pendiente/no predeterminado | Solo si Claude demuestra beneficio después de inspeccionar el export. |

## Lógica y fuentes

La propuesta prioriza simplicidad operativa y una única base de interfaz, pero separa los límites de seguridad y distribución. Supabase no vuelve segura a la app por sí solo: RLS, funciones, secretos y pruebas siguen siendo obligatorios. IONOS permanece como alternativa real; no exige reescribir React.

### Fuentes oficiales

- [Capacitor — documentación](https://capacitorjs.com/docs)
- [Capacitor — instalación en una web existente](https://capacitorjs.com/docs/getting-started)
- [Capacitor — PWA](https://capacitorjs.com/docs/web/progressive-web-apps)
- [Supabase — Securing your data](https://supabase.com/docs/guides/database/secure-data)
- [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase — Storage access control](https://supabase.com/docs/guides/storage/security/access-control)
- [Supabase — Understanding API keys](https://supabase.com/docs/guides/getting-started/api-keys)
- [Supabase — Edge Function secrets](https://supabase.com/docs/guides/functions/secrets)
- [Supabase — Database backups](https://supabase.com/docs/guides/platform/backups)
- [Anthropic — Claude Code best practices](https://code.claude.com/docs/en/best-practices)
- [Anthropic — `.claude/rules/`](https://code.claude.com/docs/en/memory#organize-rules-with-clauderules)
- [Anthropic — Claude Code Desktop](https://code.claude.com/docs/en/desktop)
