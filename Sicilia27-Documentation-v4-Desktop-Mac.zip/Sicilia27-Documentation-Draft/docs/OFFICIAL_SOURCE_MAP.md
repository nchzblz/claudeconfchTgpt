# Official Source Map

**Estado:** registro de trazabilidad para revisión.  
**Regla:** una fuente oficial puede justificar una capacidad, restricción o práctica de plataforma; no convierte una recomendación de arquitectura en un hecho inevitable.

## Cómo leer este registro

- **Requisito de producto:** viene de Nacho o de la estructura confirmada de las capturas; no necesita una autoridad externa.
- **Hecho de plataforma:** debe estar respaldado por el proveedor/organismo oficial.
- **Recomendación:** es una inferencia del proyecto basada en requisitos + hechos oficiales; se identifica como recomendación.
- **TBD:** no existe evidencia suficiente o falta una decisión; no debe rellenarse con una suposición.

## Claude Code — solo Anthropic/Claude Academy

| Decisión | Fuente oficial | Qué respalda |
|---|---|---|
| `CLAUDE.md` corto y humano | [Best practices](https://code.claude.com/docs/en/best-practices#write-an-effective-claudemd) | Incluir comandos, estilo, workflow y decisiones no inferibles; evitar documentación larga. |
| Revisar `CLAUDE.md` sin aplicarlo automáticamente | [Memory — Set up a project CLAUDE.md](https://code.claude.com/docs/en/memory#set-up-a-project-claudemd) | Claude puede analizar el proyecto y sugerir mejoras; las instrucciones deben mantenerse específicas y concisas. |
| Separar reglas por tema/ruta | [Memory — `.claude/rules/`](https://code.claude.com/docs/en/memory#organize-rules-with-clauderules) | Archivos modulares y reglas con `paths` frontmatter. |
| Explorar → planificar → implementar | [Best practices](https://code.claude.com/docs/en/best-practices#explore-first-then-plan-then-code) | Evitar programar la solución equivocada. |
| Aclarar ambigüedades con `AskUserQuestion` | [Tools reference](https://code.claude.com/docs/en/tools-reference) y [Handle user input](https://code.claude.com/docs/en/agent-sdk/user-input) | La herramienta recopila requisitos o aclara ambigüedades; es especialmente habitual durante Plan Mode. |
| Exigir verificación ejecutable | [Best practices](https://code.claude.com/docs/en/best-practices#give-claude-a-way-to-verify-its-work) | Tests, build y comparación visual como señales pass/fail. |
| Controlar contexto | [How Claude Code works](https://code.claude.com/docs/en/how-claude-code-works) | Los archivos, mensajes y outputs consumen contexto; conviene dividir trabajo. |
| Formación oficial complementaria | [Claude Academy](https://academy.claude.com/) | Recursos formativos oficiales de Anthropic. |

No se utilizaron blogs de terceros para diseñar los archivos de Claude.

Anthropic documenta `CLAUDE.md` como el archivo persistente que Claude Code carga al iniciar. No atribuye esa función especial al README; en este paquete, `START_HERE.md` es deliberadamente una portada humana y un guion de primera sesión que no colisiona con la documentación original del export.

## Claude Desktop para macOS — pestaña Code

| Decisión operativa | Fuente oficial | Qué respalda |
|---|---|---|
| Desktop comparte motor y `CLAUDE.md` con CLI | [Desktop — Coming from the CLI / Shared configuration](https://code.claude.com/docs/en/desktop#coming-from-the-cli) | La configuración y memoria del proyecto se aplican también en Desktop. |
| Sesión **Local** con carpeta raíz | [Desktop — Start a session](https://code.claude.com/docs/en/desktop#start-a-session) | Permite seleccionar entorno y carpeta de proyecto; Local usa los archivos del Mac. |
| Elegir **Plan** desde el selector | [Desktop — Choose a permission mode](https://code.claude.com/docs/en/desktop#choose-a-permission-mode) | Plan explora y propone sin editar; en Desktop reemplaza `--permission-mode`. |
| Pasar a **Manual** tras aprobar | [Desktop — Choose a permission mode](https://code.claude.com/docs/en/desktop#choose-a-permission-mode) | Manual solicita aprobación para ediciones y comandos y muestra los diffs. |
| Evitar flags/atajos del CLI | [Desktop — CLI flag equivalents](https://code.claude.com/docs/en/desktop#cli-flag-equivalents) | Los flags se sustituyen por controles gráficos; los atajos interactivos del terminal no aplican igual. |
| Claude ejecuta comandos dentro de la sesión | [Desktop — Use the prompt box](https://code.claude.com/docs/en/desktop#use-the-prompt-box) | Claude puede leer, editar y ejecutar comandos conforme al permiso elegido. |
| Browser para verificar web | [Desktop — Preview your app](https://code.claude.com/docs/en/desktop#preview-your-app) | Dev server, screenshots, DOM e interacción real dentro del pane. |
| Simulator para iOS | [Desktop — iOS Simulator](https://code.claude.com/docs/en/desktop#test-ios-apps-in-the-ios-simulator) | Verificación nativa integrada en macOS; no sustituye todas las pruebas en dispositivo físico. |
| Diff y Review code | [Desktop — Review changes / Review your code](https://code.claude.com/docs/en/desktop#review-changes-with-diff-view) | Revisión gráfica del cambio y detección adicional de errores de alta señal. |
| Transcript **Summary** | [Desktop — Switch view modes](https://code.claude.com/docs/en/desktop#switch-view-modes) | Reduce el ruido visible ocultando el detalle de herramientas. |

La suscripción Pro habilita Claude Code Desktop, pero no demuestra que Node, npm u otras herramientas del proyecto estén disponibles en el entorno Local. Claude debe inspeccionarlas antes de elegir comandos.

## Arquitectura web/nativa

| Decisión | Fuente oficial | Qué respalda / límite |
|---|---|---|
| Reutilizar app web en iOS/Android | [Capacitor docs](https://capacitorjs.com/docs) | Runtime nativo para herramientas web modernas y acceso a SDK/plugins nativos. No garantiza aprobación de tiendas. |
| Mantener también una PWA | [Capacitor PWA](https://capacitorjs.com/docs/web/progressive-web-apps) | Soporte de PWA junto a iOS/Android. |
| Añadir Capacitor al proyecto existente | [Getting Started](https://capacitorjs.com/docs/getting-started) | Capacitor puede agregarse a un proyecto web existente. |

La elección de Capacitor sobre una reescritura Swift/Kotlin es una recomendación de coste/operación del proyecto, no una orden de estas fuentes.

## Apple

| Decisión/hecho | Fuente oficial | Qué respalda |
|---|---|---|
| La app debe superar un sitio reempaquetado | [App Review 4.2](https://developer.apple.com/app-store/review/guidelines/#minimum-functionality) | Utilidad, contenido e interfaz app-like. |
| Distribución iOS *Unlisted* | [Unlisted App Distribution](https://developer.apple.com/support/unlisted-app-distribution/) | Enlace directo, no aparece en búsqueda y requiere App Review. |
| Token sigue siendo necesario | [Unlisted App Distribution](https://developer.apple.com/support/unlisted-app-distribution/) | Cualquiera con el enlace puede acceder/descargar; Apple sugiere mecanismo interno. |
| Reviewer necesita acceso completo | [App Review Guidelines — Before You Submit](https://developer.apple.com/app-store/review/guidelines/) | Demo activa/modo completo, backend disponible, QR/hardware e instrucciones. |
| Moderación de fotos/UGC | [App Review 1.2](https://developer.apple.com/app-store/review/guidelines/#user-generated-content) | Filtro, reporte, bloqueo y contacto para contenido generado por usuarios. |
| Política, retención y eliminación | [App Review 5.1.1](https://developer.apple.com/app-store/review/guidelines/#data-collection-and-storage) | Política accesible, usos, terceros, retención, revocación/eliminación y consentimiento. |
| Push no es requisito ni atajo de aprobación | [App Review 4.5.4](https://developer.apple.com/app-store/review/guidelines/#apple-sites-and-services) | Push no debe ser obligatorio; marketing requiere opt-in/opt-out. |
| Universal Links | [Supporting Associated Domains](https://developer.apple.com/documentation/Xcode/supporting-associated-domains) | Asociación segura entre dominio y app. |
| Instalación web en iPhone | [Apple Support — Turn a website into an app](https://support.apple.com/guide/iphone/iphea86e5236/ios) | Pasos manuales de Safari para agregar/abrir como web app. |

La propuesta “Unlisted + token” es una recomendación. La aprobación final siempre corresponde a App Review.

## Google Play / Android

| Decisión/hecho | Fuente oficial | Qué respalda |
|---|---|---|
| 12 testers/14 días para ciertas cuentas | [Play Console Help](https://support.google.com/googleplay/android-developer/answer/14151465) | Aplica a cuentas personales creadas después del 13 nov 2023. Debe verificarse el tipo/fecha de cuenta real. |
| Acceso a contenido restringido | [Prepare your app for review](https://support.google.com/googleplay/android-developer/answer/9859455) | Instrucciones especiales, privacidad y declaraciones de contenido. |
| Datos y privacidad | [User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311) | Política que describa acceso, colección, uso y compartición. |
| Enlaces verificados | [Android App Links](https://developer.android.com/training/app-links/about) | Asociación de dominio mediante `assetlinks.json`. |

## PWA y accesibilidad

| Decisión/hecho | Fuente oficial/estándar | Qué respalda |
|---|---|---|
| `beforeinstallprompt` no sirve como única ruta en iOS | [MDN — Making PWAs installable](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable) | El evento permite prompt en navegadores compatibles y no está soportado en iOS. |
| Objetivo WCAG 2.2 AA | [W3C — WCAG 2.2](https://www.w3.org/TR/WCAG22/) | Criterios de accesibilidad web. |
| Targets mínimos y recomendación de amplitud | [W3C — Target Size Minimum](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum) y [Enhanced](https://www.w3.org/WAI/WCAG22/Understanding/target-size-enhanced) | 24×24 CSS px para AA con excepciones; 44×44 en criterio mejorado. |
| Alternativa a movimiento | [W3C — Animation from Interactions](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions) | Riesgos y desactivación de movimiento no esencial. |

MDN es la documentación mantenida por Mozilla para la Web Platform; Apple Support es la autoridad del flujo iOS. La animación de cursor dentro de la web es un diseño propio; no debe presentarse como control de la hoja nativa.

## Supabase y datos

| Decisión/hecho | Fuente oficial | Qué respalda |
|---|---|---|
| RLS y seguridad de datos | [Securing your data](https://supabase.com/docs/guides/database/secure-data) | RLS y claves; secretos no van al frontend. |
| Secret key solo backend | [API keys](https://supabase.com/docs/guides/getting-started/api-keys) | Secret keys omiten RLS y nunca se exponen en browser/app/source. |
| Storage privado controlado | [Storage access control](https://supabase.com/docs/guides/storage/security/access-control) | Storage se integra con políticas RLS y no permite uploads sin políticas por defecto. |
| Archivos de 3 MB por upload estándar | [Standard uploads](https://supabase.com/docs/guides/storage/uploads/standard-uploads) | Método ideal para archivos no mayores de 6 MB. |
| Backups | [Database backups](https://supabase.com/docs/guides/platform/backups) | Backups diarios según plan y export regular en Free; detalles de restauración/PITR. |
| Secretos de funciones | [Edge Function secrets](https://supabase.com/docs/guides/functions/secrets) | Variables secretas server-side. |

Elegir Supabase sobre IONOS es una recomendación de simplicidad. Capacidad y coste deben comprobarse en el plan vigente y en la cuenta IONOS real.

## Spotify

| Decisión/hecho | Fuente oficial | Qué respalda |
|---|---|---|
| Búsqueda de tracks y carátulas | [Search](https://developer.spotify.com/documentation/web-api/reference/search) | Resultados de catálogo con track, artista, álbum e imágenes. |
| Client Credentials server-side | [Getting started](https://developer.spotify.com/documentation/web-api/tutorials/getting-started) | Apropiado cuando el backend consulta datos sin actuar por un usuario. |
| No login/playlist para este caso | [Authorization](https://developer.spotify.com/documentation/web-api/concepts/authorization) | Diferencia datos de aplicación vs recursos privados del usuario. |
| Carátula intacta, atribución y enlace | [Get Track policy notes](https://developer.spotify.com/documentation/web-api/reference/get-track) | No descargar contenido; no modificar visuales; atribuir/enlazar a Spotify. |

## Calendario

| Decisión | Fuente estándar | Qué respalda |
|---|---|---|
| Descargar eventos `.ics` | [RFC 5545](https://www.rfc-editor.org/rfc/rfc5545) | Formato iCalendar interoperable. |

Elegir `.ics` en vez de pedir acceso completo al calendario es una recomendación de minimización de permisos.

## Reglas que no vienen de una plataforma externa

Estas cifras y comportamientos son requisitos confirmados por Nacho, no afirmaciones documentales:

- 65 invitaciones.
- Tres días y decisión de +1 separada por día.
- Shuttle solo Día 3.
- Máximo tres canciones.
- 50 fotos por token, 10 por lote, 3 MB por archivo.
- Fotos ocultas hasta aprobar.
- RSVP bloqueado después de enviar.
- RSVP oculto el 31 de mayo de 2027.
- Envío manual por WhatsApp el 1 de noviembre de 2026.

## Lógica de este archivo

Centralizar la trazabilidad evita repetir explicaciones extensas y permite volver a comprobar políticas inestables antes de publicar. Cada documento conserva además sus fuentes más próximas para que no dependa únicamente de este índice.
