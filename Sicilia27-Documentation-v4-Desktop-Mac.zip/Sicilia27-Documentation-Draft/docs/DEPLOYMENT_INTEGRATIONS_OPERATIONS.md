# Deployment, Integrations & Operations

**Estado:** propuesta operativa.  
**Fecha objetivo declarada:** producto listo a principios de octubre de 2026; invitaciones enviadas manualmente el 1 de noviembre de 2026.  
**Riesgo actual:** al 15 de septiembre de 2026 no está confirmada el alta en Apple Developer ni Google Play, y la distribución *Unlisted* de Apple se solicita después de tener una app lista y sometida a App Review.

## 0. Entorno de desarrollo y revisión

- Superficie: Claude Desktop para macOS, pestaña **Code**, plan Pro.
- Entorno predeterminado: **Local**, con la carpeta raíz de Sicilia27 seleccionada.
- Tareas complejas empiezan en **Plan** desde el selector gráfico; después de aprobar, se cambia a **Manual**.
- Claude ejecuta los comandos del proyecto dentro de la sesión. Antes inspecciona runtime, lockfile y scripts; no presupone npm ni nombres de scripts.
- Web/PWA se verifica en Browser pane; iOS en Simulator cuando corresponda; el flujo PWA de Safari, cámara, permisos y rendimiento final se validan también en dispositivo físico.
- Cada cambio se revisa en Diff; Review code y Codex aportan controles adicionales, pero no sustituyen tests/build/verificación visual.

## 1. Estrategia de lanzamiento

### Base garantizable

La PWA en `rsvp.sicilia2027.com` debe ser el canal de lanzamiento garantizable para el 1 de noviembre. iOS y Android se trabajan en paralelo, pero ninguna fecha interna debe depender de una aprobación externa que no controlamos.

### iOS

**RECOMENDADO:** App Store *Unlisted*.

- No aparece en búsqueda, categorías o rankings; se accede mediante enlace directo.
- Sigue pasando App Review.
- El enlace no es autorización: cualquiera que lo tenga puede descargar; el token mantiene privado el contenido.
- En Review Notes se entrega token demo activo, QR de prueba, backend disponible y explicación de funciones no obvias.
- La app debe aportar utilidad nativa/app-like: Hub recurrente, enlaces profundos, cámara/fotos, contenido offline, notificaciones opcionales y estados dinámicos. Agregar notificaciones por sí solo no mejora aprobación; Apple exige utilidad general y dice que push no puede ser obligatorio.

**Acciones inmediatas externas:** crear/verificar cuenta Apple Developer, confirmar nombre legal del publisher y preparar certificados/App Store Connect. No incluir credenciales en el repo.

### Android

- Confirmar si existe cuenta y si es personal u organización.
- Si es una cuenta personal creada después del 13 de noviembre de 2023, Google exige actualmente una prueba cerrada con al menos 12 testers inscritos continuamente durante 14 días antes de solicitar acceso a producción.
- Aunque el contenido esté bloqueado por token, Play Console necesita instrucciones de acceso para revisión.
- Preparar política de privacidad, Data Safety, target audience, content rating y declaración de permisos.

### PWA

- Manifest, service worker, iconos y `display: standalone`.
- iOS: tutorial manual Compartir → Agregar a pantalla de inicio; no depender de `beforeinstallprompt`.
- Android compatible: usar `beforeinstallprompt` si el navegador lo ofrece.
- Detectar modo standalone y no repetir onboarding.

## 2. Dominios

| Host | Uso recomendado |
|---|---|
| `sicilia2027.com` | Página pública mínima/ayuda/privacidad o redirección. |
| `rsvp.sicilia2027.com` | Guest PWA y enlaces personales. |
| `admin.sicilia2027.com` | Event Control Center, si DNS/hosting lo facilita. |

Si otro host simplifica IONOS, puede usarse sin cambiar la arquitectura. HTTPS es obligatorio para PWA, enlaces verificados y secretos en tránsito.

## 3. Enlaces personales y deep links

- URL canónica: `https://rsvp.sicilia2027.com/i/<token>` o parámetro equivalente; la forma definitiva se decide antes de imprimir/enviar.
- iOS publica `apple-app-site-association` y configura Associated Domains.
- Android publica `/.well-known/assetlinks.json` y configura App Links verificados.
- La misma URL funciona como web fallback.
- Tras validar, quitar el token de la URL visible y no enviarlo como referrer a terceros.
- No cargar Spotify, mapas, analytics o imágenes externas antes de retirar el token del URL.

## 4. Spotify

### Implementación recomendada

1. Guest app llama a `spotify-search` del backend con texto normalizado.
2. Función aplica longitud mínima, debounce cliente, rate limit y caché breve.
3. Backend usa Client Credentials para datos de catálogo no ligados a un usuario.
4. `SPOTIFY_CLIENT_SECRET` vive únicamente en secretos del servidor.
5. Respuesta mínima: track ID/URI, título, artistas, álbum/versión, duración opcional, carátula y URL externa.
6. UI muestra resultados; el usuario selecciona hasta tres.

No pedir login de Spotify: no se accede a datos privados ni se crea playlist. Client Credentials es apropiado para una aplicación backend que consulta datos públicos/no personales.

### Obligaciones visuales

- No descargar audio.
- No recortar, superponer ni modificar la carátula.
- Mostrar atribución/logo y enlace al track/álbum/artista aplicable según la política oficial.
- Revisar Developer Terms antes del release porque pueden cambiar.

## 5. Fotos

### Flujo técnico

1. QR de Día 2 abre enlace firmado/revisionado.
2. `photo-unlock` valida sesión de invitado, fecha/ventana y secreto QR.
3. Primera carga registra consentimiento.
4. Cliente selecciona hasta 10; rechaza no-imágenes.
5. Si un archivo supera 3 MB, lo optimiza gradualmente; conserva dimensiones si alcanza el límite sin reducirlas.
6. Backend emite tickets/rutas únicas y vuelve a validar cuota.
7. Carga a bucket privado con estado `pending`.
8. Moderador ve miniatura y original, aprueba/rechaza.
9. Solo `approved` puede aparecer en galería final.

Supabase recomienda upload estándar para archivos de hasta 6 MB, por lo que el límite de 3 MB encaja. El límite se aplica también en bucket/política/función, no solo con JavaScript.

### Capacidad

- Máximo teórico: 9.750 MB decimales (aprox. 9,75 GB) si 65 invitados suben 50 fotos de exactamente 3 MB.
- Presupuestar margen para miniaturas, versiones moderadas, logs y backups.
- No afirmar que un plan soporta esa capacidad hasta revisar límites/precio vigente.

### Privacidad y UGC

- Fotos privadas por defecto.
- Publicar consentimiento, atribución, retención y canal de eliminación.
- Si hay galería aprobada: reporte/contacto y revocación/bloqueo del autor, además de moderación previa, para cubrir UGC de Apple.
- Pedir cámara/fototeca solo cuando el usuario elige esa acción y explicar el propósito.

## 6. Calendario

- Generar `.ics` conforme a RFC 5545 con solo los días `yes` del titular.
- Incluir zona `Europe/Rome`, UID estable y revisión para evitar duplicados.
- Si cambia hora/lugar tras descargar, mostrar aviso y permitir agregar versión actualizada.
- No crear calendario remoto ni pedir acceso completo al calendario si un archivo `.ics` resuelve el objetivo con menos permiso.

## 7. Notificaciones y WhatsApp

### Primera versión

- WhatsApp manual desde el panel mediante enlace prellenado; el operador marca `sent`.
- Avisos importantes también visibles dentro de Home.
- Push nativo es opcional, con opt-in y opt-out; nunca necesario para usar la app.
- PWA Web Push se evalúa después de validar valor y soporte real; WhatsApp sigue siendo fallback.

No automatizar WhatsApp inicialmente: requiere proveedor, plantillas, consentimiento/coste y operación adicionales que no son necesarios para 65 envíos manuales.

## 8. Email de cancelación

- Destinatario: `ORGANIZER_NOTIFICATION_EMAIL` (TBD).
- Proveedor: interfaz desacoplada, proveedor TBD.
- Email se crea mediante outbox idempotente dentro de la transición de cancelación.
- Si envío falla, el RSVP permanece cancelado y el panel muestra error/reintento; no se revierte el estado del invitado.

## 9. Privacidad y permisos

Publicar una URL estable de política de privacidad dentro de la app y en ambas tiendas. Debe explicar:

- nombre, teléfono, idioma y RSVP;
- restricciones alimentarias (dato potencialmente sensible por inferencia);
- canciones/mensaje;
- fotos, autoría y moderación;
- proveedores y finalidad;
- retención y eliminación;
- contacto.

Declarar exactamente datos/permisos reales en Apple App Privacy y Google Data Safety. No agregar analytics publicitaria. Telemetría operativa mínima: abierto, iniciado, completado, errores técnicos, sin token ni contenido personal en logs.

## 10. Backups y recuperación

### Base de datos

- Activar plan/backups acordes antes de envíos reales.
- En Supabase Pro/Team/Enterprise existen backups diarios; Free requiere exports regulares según su documentación vigente.
- Además, exportar semanalmente durante RSVP y diariamente en la semana del evento a un destino fuera del proyecto.
- Antes de migraciones: backup lógico + prueba de restauración en entorno separado.

### Fotos

- Los backups de base no necesariamente equivalen a una copia utilizable de objetos; documentar y ejecutar export de Storage.
- Mantener manifiesto `photo_id → path → hash → status → author` junto al backup.
- No borrar proyecto hasta verificar DB, objetos y exportaciones.

### Recuperación mínima ensayada

1. Restaurar DB en proyecto/entorno de prueba.
2. Restaurar una muestra de Storage.
3. Confirmar totales RSVP y hashes de fotos.
4. Abrir panel sin tocar producción.
5. Registrar fecha, responsable y resultado.

## 11. Entornos y secretos

| Entorno | Datos | Uso |
|---|---|---|
| Local | ficticios | Desarrollo; jamás invitados reales. |
| Staging | invitados ficticios + QR demo | Revisión Claude/Codex, dispositivos y tiendas. |
| Production | datos reales | Solo releases aprobados. |

- Proyectos/keys distintos entre staging y production.
- Secretos solo en gestores de plataforma.
- `.env.example` sin valores reales.
- Token demo separado y revocable para App Review/Google review.

## 12. Checklist de release

### Funcional

- Matriz RSVP y cancelación pasa en español/inglés.
- Borrador retoma; confirmado bloquea; submit idempotente.
- Spotify real probado con versiones/cover/enlace.
- `.ics` contiene solo días confirmados.
- QR Día 2 y cuotas de fotos pasan en dispositivo.
- Panel, export y email/error visibles.

### Seguridad/privacidad

- RLS y funciones probadas con invitación A intentando datos B.
- Ningún secreto/token en bundle, source maps, logs o analytics.
- Buckets pendientes privados.
- Política y declaraciones de tiendas coinciden con código.

### Calidad

- Pasan los scripts reales y aprobados de lint, typecheck, tests y build identificados en el proyecto.
- Browser y Simulator pasan durante desarrollo; pruebas finales reales en iPhone/Safari/PWA y Android/Chrome quedan documentadas.
- VoiceOver/TalkBack, texto ampliado, contraste, targets y reduced motion.
- Offline no muestra confirmaciones falsas.

### Tiendas

- Demo token/QR e instrucciones de review.
- Backend activo durante review.
- Screenshots, metadata y contenido finales.
- Funciones no obvias descritas con precisión.
- No enviar una beta incompleta como producción.

## 13. Lógica y fuentes

El plan hace de la PWA el canal controlable y trata las tiendas como dependencias externas. Los secretos de Spotify se aíslan en backend; fotos se mantienen privadas; permisos se solicitan en contexto. La estrategia evita añadir funciones decorativas únicamente para “pasar Apple”: el criterio oficial es la utilidad completa, no una casilla de notificaciones.

### Fuentes oficiales

- [Apple — App Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)
- [Apple — Unlisted App Distribution](https://developer.apple.com/support/unlisted-app-distribution/)
- [Apple — Supporting Associated Domains](https://developer.apple.com/documentation/Xcode/supporting-associated-domains)
- [Apple — Turn a website into an app in Safari](https://support.apple.com/guide/iphone/iphea86e5236/ios)
- [Google Play — Testing requirements for new personal accounts](https://support.google.com/googleplay/android-developer/answer/14151465)
- [Google Play — Prepare your app for review](https://support.google.com/googleplay/android-developer/answer/9859455)
- [Google Play — App access for review](https://support.google.com/googleplay/android-developer/answer/15748846)
- [Android — About App Links](https://developer.android.com/training/app-links/about)
- [Spotify — Client Credentials / getting started](https://developer.spotify.com/documentation/web-api/tutorials/getting-started)
- [Spotify — Search](https://developer.spotify.com/documentation/web-api/reference/search)
- [Spotify — Get Track policy notes](https://developer.spotify.com/documentation/web-api/reference/get-track)
- [Supabase — Standard uploads](https://supabase.com/docs/guides/storage/uploads/standard-uploads)
- [Supabase — Storage access control](https://supabase.com/docs/guides/storage/security/access-control)
- [Supabase — Database backups](https://supabase.com/docs/guides/platform/backups)
- [Supabase — API keys](https://supabase.com/docs/guides/getting-started/api-keys)
- [RFC Editor — RFC 5545 iCalendar](https://www.rfc-editor.org/rfc/rfc5545)
- [Anthropic — Claude Code Desktop](https://code.claude.com/docs/en/desktop)
