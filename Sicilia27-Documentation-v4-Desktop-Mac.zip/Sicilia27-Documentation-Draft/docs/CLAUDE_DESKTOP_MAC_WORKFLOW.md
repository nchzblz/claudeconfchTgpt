# Claude Desktop Mac Workflow

**Usuario:** Nacho, plan Pro.  
**Aplicación:** Claude Desktop para macOS.  
**Superficie:** pestaña **Code**, no Chat, Cowork ni CLI.  
**Entorno predeterminado:** Local.

## 1. Inicio de la primera sesión

1. Actualizar Claude Desktop desde **Claude → Check for Updates**.
2. Abrir **Code** y crear una sesión nueva.
3. Elegir **Local** y seleccionar la carpeta raíz `sicilia27/`.
4. Elegir **Plan** desde el selector junto al botón de envío; `Cmd + Shift + M` abre el menú de permisos.
5. Elegir **Summary** en Transcript view si se desea reducir el detalle visual de herramientas.
6. Enviar el prompt de `START_HERE.md`.

Plan permite a Claude leer archivos y ejecutar acciones de exploración sin editar el código. No se cambia de modo hasta que Nacho apruebe expresamente el plan.

## 2. Ciclo obligatorio por tarea compleja

| Momento | Modo/pane Desktop | Acción |
|---|---|---|
| Comprender | **Plan** | Leer código/documentos y detectar contradicciones. |
| Aclarar | `AskUserQuestion` | Preguntar si algo material no está al menos 99 % claro. |
| Decidir | Plan pane/chat | Presentar máximo 10 puntos y esperar aprobación. |
| Implementar | **Manual** | Editar solo el corte aprobado y solicitar permisos. |
| Verificar web | Browser pane | Iniciar la app, recorrer estados y comparar visualmente. |
| Verificar iOS | iOS Simulator pane | Probar el build nativo cuando corresponda. |
| Revisar | Diff + Review code | Revisar archivo por archivo; después solicitar revisión independiente de Codex. |

No usar Bypass permissions. Accept edits puede evaluarse más adelante para tareas pequeñas y repetibles, pero no es el modo inicial del proyecto.

## 3. Comandos y herramientas

Claude ejecuta comandos dentro de la sesión Code. Nacho no debe copiar comandos a macOS Terminal como parte del flujo normal.

Antes de ejecutar o recomendar cualquier comando, Claude inspecciona:

- `package.json` y posibles archivos de workspace;
- lockfile real (`package-lock`, `pnpm-lock`, `yarn.lock`, etc.);
- scripts disponibles;
- versiones/configuración requeridas;
- estado Git y cambios preexistentes.

No se presupone `npm install`, `npm run lint`, `npm test` ni `npm run build`. Lint y typecheck se consideran controles distintos salvo que el script real demuestre lo contrario. Si falta Node, un package manager, Xcode, Simulator u otra dependencia, Claude informa el bloqueo brevemente y pregunta antes de instalar o cambiar configuración.

## 4. Verificación visual

- Browser pane: servidor local, interacción, screenshots, DOM, errores y estados web/PWA.
- iOS Simulator: build y comportamiento nativo inicial en macOS.
- Dispositivo real: Safari/PWA, instalación en pantalla de inicio, permisos, cámara/fotos, notificaciones y rendimiento final cuando corresponda.
- Diff: Nacho revisa cambios archivo por archivo antes de aceptarlos.
- Review code: control adicional de errores de alta señal; no reemplaza linter, typecheck, tests, build, revisión visual ni Codex.

## 5. Contexto y sesiones

- Una fase o tarea delimitada por sesión; no implementar todo Sicilia27 en una conversación.
- Mantener `CLAUDE.md` breve y estable; documentación extensa permanece en `docs/`.
- Usar side chat (`Cmd + ;`) para preguntas que no deben alterar el hilo principal.
- Mantener Transcript view en **Summary** cuando el detalle de herramientas genere ruido; cambiar a Verbose solo para diagnosticar una acción.
- Si Claude empieza a implementar en Plan, hace suposiciones o produce una respuesta excesiva, Nacho debe pulsar Stop y corregir antes de continuar.

## 6. Diferencias que este proyecto no debe confundir

| CLI/terminal | Equivalente correcto en Desktop |
|---|---|
| `claude --permission-mode plan` | Selector gráfico **Plan**. |
| `Shift + Tab` para cambiar permisos | Selector o `Cmd + Shift + M`. |
| Varias terminales | Varias sesiones en la barra lateral. |
| Revisión textual de diffs | Diff pane y comentarios por línea. |
| Abrir servidor/navegador manualmente | Browser pane y configuración de preview. |
| Automatización `--print` | No disponible en Desktop; no usar en este flujo. |

## 7. Lógica

Claude Desktop usa el mismo motor y los mismos archivos `CLAUDE.md` que el CLI, por lo que la arquitectura del producto y las reglas del repositorio no cambian por usar interfaz gráfica. Sí cambia la operación: permisos, revisión, terminal, navegador y Simulator se gestionan desde panes y selectores de Desktop. Este archivo evita convertir instrucciones del CLI en tareas manuales para Nacho.

## Fuentes oficiales de Anthropic

- [Claude Code Desktop](https://code.claude.com/docs/en/desktop)
- [Claude Code Desktop quickstart](https://code.claude.com/docs/en/desktop-quickstart)
- [Best practices for Claude Code](https://code.claude.com/docs/en/best-practices)
- [How Claude remembers your project](https://code.claude.com/docs/en/memory)
- [Tools reference — AskUserQuestion](https://code.claude.com/docs/en/tools-reference)
