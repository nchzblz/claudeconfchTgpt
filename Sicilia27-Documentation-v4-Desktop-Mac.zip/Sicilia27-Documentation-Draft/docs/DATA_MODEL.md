# Logical Data Model

**Estado:** propuesta para revisión; nombres físicos pueden ajustarse en migraciones.  
**Principio:** guardar solo datos necesarios, con restricciones en base de datos además de validación de interfaz.

## 1. Entidades

```mermaid
erDiagram
    INVITATION ||--|| RSVP : owns
    RSVP ||--|{ RSVP_DAY : answers
    RSVP ||--o{ SONG_SUGGESTION : includes
    INVITATION ||--o| PHOTO_UNLOCK : receives
    INVITATION ||--o{ PHOTO : uploads
    ADMIN_USER ||--o{ AUDIT_EVENT : performs
```

## 2. `invitations`

Una fila por invitación/token, no por asistente físico.

| Campo | Tipo lógico | Regla |
|---|---|---|
| `id` | UUID | PK interna; no usar como credencial. |
| `primary_name` | text | Requerido. |
| `language` | enum `es`, `en-US` | Requerido; determina copy inicial. |
| `phone_e164` | text | Requerido para envío manual; validar formato. |
| `has_plus_one` | boolean | Requerido. |
| `origin_location` | text nullable | Administrativo; no altera UI. |
| `token_hash` | text unique | Derivado de token; nunca devolver al cliente. |
| `token_ciphertext` | text nullable | Solo si se aprueba enlace recuperable; acceso administrativo de servidor. |
| `access_status` | enum `active`, `cancelled`, `revoked` | Controla acceso. |
| `delivery_status` | enum `pending`, `sent` | El “abierto/en progreso/confirmado/cancelado” se deriva de eventos/RSVP. |
| `sent_at` | timestamptz nullable | Marcado manualmente. |
| `first_opened_at` | timestamptz nullable | Se establece una vez. |
| `created_at`, `updated_at` | timestamptz | Auditoría básica. |

### Restricciones

- `token_hash` único.
- Teléfono no se expone al guest client salvo necesidad explícita.
- Cancelar/revocar no borra automáticamente datos; cambia autorización.

## 3. `event_days`

Datos estructurales de cada celebración; el copy largo permanece en archivos bilingües.

| Campo | Regla |
|---|---|
| `id` / `day_number` | Solo 1, 2, 3; único. |
| `starts_at`, `ends_at` | Zona `Europe/Rome`; fin puede ser TBD hasta confirmar. |
| `venue_name`, `address`, `map_url` | Valores editables; Día 1 inicialmente TBD. |
| `has_shuttle` | Verdadero solo Día 3. |
| `calendar_revision` | Incrementa cuando cambian datos usados en `.ics`. |

### Lógica

Fechas y lugares que afectan calendario/validación no deben duplicarse en varios componentes. El texto editorial se versionará en el directorio canónico de contenido que se apruebe después de auditar el export; la estructura candidata usa `src/content`.

## 4. `rsvps`

Una fila única por invitación; sirve también como borrador.

| Campo | Tipo/regla |
|---|---|
| `id` | UUID PK. |
| `invitation_id` | FK unique a `invitations`. |
| `status` | `not_started`, `draft`, `confirmed`, `cancelled`. |
| `current_step` | Último paso seguro para retomar. |
| `primary_dietary` | text nullable. |
| `companion_name` | text nullable. |
| `companion_dietary` | text nullable. |
| `needs_day3_shuttle` | boolean nullable mientras no se responda/aplique. |
| `personal_message` | text nullable; límite final TBD. |
| `confirmed_at` | timestamptz nullable. |
| `cancelled_at` | timestamptz nullable. |
| `submission_version` | integer; incrementado por servidor. |
| `idempotency_key` | text nullable unique. |
| `created_at`, `updated_at` | timestamptz. |

### Reglas

- `invitation_id` único impide dos RSVP.
- Guest update permitido solo en `not_started` o `draft`.
- `confirmed` y `cancelled` son terminales para el invitado.
- `needs_day3_shuttle` solo puede tener valor si asiste al Día 3; decisión exacta de si es obligatorio responder: TBD.
- Nombre/restricción del +1 solo se conservan si existe permiso y al menos un `companion_attending = true`; si cambia a no asistir, el UI puede conservar borrador durante edición, pero el submit debe normalizar datos incoherentes.

## 5. `rsvp_days`

| Campo | Tipo/regla |
|---|---|
| `rsvp_id` | FK. |
| `event_day_id` | FK. |
| `primary_attendance` | `unanswered`, `yes`, `no`. |
| `companion_attendance` | `not_applicable`, `unanswered`, `yes`, `no`. |
| `updated_at` | timestamptz. |

Clave única `(rsvp_id, event_day_id)`.

### Validaciones de confirmación

- Deben existir exactamente tres filas.
- Ningún `primary_attendance` queda `unanswered`.
- Si titular = `no`, acompañante = `not_applicable` o `no`, nunca `yes`.
- Si titular = `yes` y tiene +1, acompañante no queda `unanswered`.
- Si no tiene +1, acompañante siempre `not_applicable`.
- Tres titulares = `no` solo permiten transición a `cancelled`, no a `confirmed`.

Usar enum/estado explícito evita el error del prototipo: un booleano inicial no distingue “No” de “todavía no respondió”.

## 6. `song_suggestions`

| Campo | Regla |
|---|---|
| `id` | UUID PK. |
| `rsvp_id` | FK. |
| `position` | 1–3; unique por RSVP. |
| `spotify_track_id` / `spotify_uri` | Requeridos. |
| `track_name` | Requerido. |
| `artist_names` | Array/text requerido. |
| `album_name` | Requerido. |
| `album_image_url` | URL de Spotify. |
| `spotify_external_url` | Requerido para atribución/enlace. |
| `created_at` | timestamptz. |

### Reglas

- Máximo tres mediante posición/check + validación transaccional.
- No guardar audio, previews descargados, playlists ni resultados de otros invitados.
- Carátula sin recortar/superponer; mostrar atribución y enlace a Spotify según su política.

## 7. `photo_unlocks`

| Campo | Regla |
|---|---|
| `invitation_id` | PK/FK. |
| `unlocked_at` | Requerido. |
| `expires_at` | Requerido; ventana del evento. |
| `consent_accepted_at` | Nullable hasta primera carga. |
| `qr_revision` | Permite rotar/revocar el QR físico. |

El secreto QR no se guarda legible en esta tabla ni se imprime en logs.

## 8. `photos`

| Campo | Regla |
|---|---|
| `id` | UUID PK. |
| `invitation_id` | FK; autor verificable. |
| `storage_path` | Único, bucket privado. |
| `original_filename` | Sanitizado; no usar como path. |
| `mime_type` | Permitido después de verificar contenido. |
| `bytes` | `<= 3,145,728`. |
| `width`, `height` | Requeridos tras validación. |
| `status` | `pending`, `approved`, `rejected`, `deleted`. |
| `moderated_by`, `moderated_at` | Nullable hasta moderación. |
| `rejection_reason` | Nullable, administrativo. |
| `created_at` | timestamptz. |

### Reglas

- Máximo 50 filas no eliminadas por invitación, aplicado transaccionalmente.
- Cada lote solicita como máximo 10 tickets de subida.
- Bucket privado; objeto pendiente nunca tiene URL pública.
- Aprobación no mueve necesariamente el original a bucket público: una función puede entregar URL firmada o copia publicada, según galería final.
- Recomendación de privacidad: retirar metadatos GPS antes de publicar. Esto no requiere reducir dimensiones, pero debe probarse que la canalización no recompone innecesariamente imágenes <=3 MB.

## 9. Panel y auditoría

### `admin_users`

Referencia al usuario autenticado de Supabase Auth, rol mínimo `owner` o `moderator`. Empezar con un único owner; no construir un sistema complejo de permisos sin necesidad.

### `audit_events`

| Campo | Uso |
|---|---|
| `actor_type`, `actor_id` | guest/admin/system. |
| `action` | `mark_sent`, `rsvp_confirm`, `rsvp_cancel`, `photo_approve`, etc. |
| `entity_type`, `entity_id` | Recurso afectado. |
| `metadata` | Solo datos técnicos mínimos; no copiar tokens ni textos sensibles. |
| `created_at` | Inmutable. |

### `notification_outbox`

Tabla recomendada para que confirmación/cancelación y email sean transaccionalmente coordinados.

- `event_type`, `entity_id`, `recipient`, `payload`, `status`, `attempts`, `last_error`.
- Unique `(event_type, entity_id)` para no duplicar email en retries.
- El proveedor de correo permanece TBD.

## 10. Vista del Event Control Center

Los estados del panel se derivan así:

| Estado mostrado | Condición |
|---|---|
| Pendiente de envío | `delivery_status = pending`. |
| Enviado | `sent_at` existe y no abrió. |
| Abierto | `first_opened_at` existe y RSVP no iniciado. |
| En progreso | `rsvps.status = draft`. |
| Confirmado | `rsvps.status = confirmed`. |
| Cancelado | `rsvps.status = cancelled` o acceso cancelado. |

No guardar un segundo “estado general” que pueda contradecir estas columnas.

## 11. Exportación / Google Sheets

- La base es fuente de verdad.
- Exportar vistas planas: Invitaciones, Asistencia por día, Restricciones/Shuttle, Canciones/Mensajes y Fotos.
- Incluir IDs internos estables y `exported_at`, nunca token ni hash.
- La sincronización bidireccional queda fuera de alcance inicial; evita que una edición accidental de Sheet modifique la base.

## 12. Retención y eliminación

- El RSVP desaparece de la UI el 31 de mayo de 2027, pero no se borra automáticamente.
- Conservar hasta exportación y decisión manual de eliminación.
- Publicar política con datos recogidos, uso, terceros, retención y canal de eliminación.
- Una solicitud de eliminación debe poder marcar/borrar datos y fotos vinculados sin borrar estadísticas agregadas no identificables, sujeto a decisión legal.

## 13. Lógica y fuentes

El modelo usa claves únicas, estados terminales y restricciones porque la validación de UI no evita retries o clientes manipulados. Storage privado + RLS es el punto de partida; las claves administrativas omiten RLS y por eso permanecen en backend. Los metadatos Spotify se limitan a lo necesario para identificar la versión y cumplir atribución.

### Fuentes oficiales

- [Supabase — Securing your data](https://supabase.com/docs/guides/database/secure-data)
- [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)
- [Supabase — Storage access control](https://supabase.com/docs/guides/storage/security/access-control)
- [Supabase — Standard uploads](https://supabase.com/docs/guides/storage/uploads/standard-uploads)
- [Supabase — Understanding API keys](https://supabase.com/docs/guides/getting-started/api-keys)
- [Spotify — Search](https://developer.spotify.com/documentation/web-api/reference/search)
- [Spotify — Get Track and attribution requirements](https://developer.spotify.com/documentation/web-api/reference/get-track)
- [Apple — Privacy requirements](https://developer.apple.com/app-store/review/guidelines/#privacy)
- [Google Play — User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311)
