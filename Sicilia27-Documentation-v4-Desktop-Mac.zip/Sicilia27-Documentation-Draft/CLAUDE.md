# Sicilia27

## Execution surface

- Nacho works in Claude Desktop for macOS, **Code** tab, with a Pro subscription.
- Use a **Local** Desktop session with the Sicilia27 project root selected unless Nacho explicitly approves another environment.
- For the first project session, Nacho selects **Plan** from Desktop's permission-mode selector. Do not give him CLI flags or terminal-only keyboard shortcuts.
- After a plan is approved, default to **Manual** mode so Nacho can review proposed edits and commands. Never request Bypass permissions for this project.
- Run necessary project commands yourself inside the Code session. Do not tell Nacho to open macOS Terminal unless a confirmed environment blocker cannot be resolved within Desktop and he approves that step.

## Product truth

- This is a private, mobile-only bilingual event app for Mariana & Lukas's 10th anniversary in Sicily, 28–30 May 2027.
- The existing code and screenshots are a prototype, not the final visual or product specification.
- `PROJECT_BRIEF.md` and `docs/PRODUCT_AND_UX_SPEC.md` are the current records of Nacho's intent and confirmed requirements, not infallible technical specifications. Audit them and ask if code, platform facts, or other documents conflict.
- Ignore `design.md` even if it exists in history or a stale checkout.
- Never turn a `TBD` into invented content. Keep a typed placeholder and report the blocker.

## Working method

- The first project session is review-only and must remain in Plan Mode. Inspect the project, question the supplied material, and wait for Nacho's approval before editing files, installing packages, or writing code.
- Treat the Google AI Studio export and all ChatGPT-authored documents as reviewable inputs, not automatically correct implementation decisions. They exist to communicate intent and save investigation time.
- Before changing code in later sessions, inspect the affected flow and write a short plan.
- Do not modify unrelated files or redesign outside the requested scope.
- Preserve confirmed RSVP behavior even when reorganizing the UI.
- When a request conflicts with the product docs, stop and ask Nacho which source should change.
- Explain material choices in the handoff and link the official documentation used.
- Keep each implementation session to one approved phase or bounded task. Use Desktop's Diff view for review before treating edits as accepted.

## Uncertainty and questions

- Do not infer, hallucinate, silently choose, or complete missing product information.
- If a requirement, expected behavior, architecture decision, content choice, visual decision, scope, cost, or delivery consequence is not at least 99% clear, stop and use `AskUserQuestion` before proceeding.
- Ask rather than converting an ambiguity into an implementation detail, even when one option appears conventional or technically preferable.
- Never resolve a `TBD`, contradiction, or conflict between the prototype, documentation, and code autonomously. Explain the conflict briefly, provide a recommendation with its trade-off, and wait for Nacho's answer.
- When several related uncertainties exist, use `AskUserQuestion` with no more than three concise questions at a time. Do not bury questions inside a long report.
- A recommendation is not approval. Record material decisions only after Nacho explicitly accepts them.

## Communication with Nacho

- Default to a maximum of 10 short bullets or an equivalent brief response.
- Lead with the decision, blocker, or question. Avoid long introductions, repeated context, and exhaustive narration.
- Expand only when Nacho explicitly asks for more detail.

## Non-negotiable behavior

- Invalid tokens reveal no guest and never fall back to a demo profile.
- Attendance starts unanswered; never preselect yes, no, +1, shuttle, song, or consent.
- A +1 cannot attend a day the primary guest declines.
- Shuttle exists only for Day 3. Songs and message are optional; songs are limited to three.
- Submitted RSVP data is read-only. Cancellation is a separate, explicit two-step flow.
- “My RSVP” shows only confirmed days and solo/+1 status.
- The current QR/pass is fictional and must not be presented as valid access control.
- Guest clients never receive database secrets, Spotify client secrets, or admin capabilities.

## Verification in Claude Desktop

- Before running any project command, inspect the actual `package.json`, lockfile, workspace configuration, and available scripts. Do not assume npm, a script name, or that lint performs typechecking.
- Use the package manager and scripts already defined by the inspected project. If a required verification script or runtime is absent, report the gap briefly and use `AskUserQuestion` before adding, installing, or changing tooling.
- For every material change, run the narrowest relevant check first, then the full relevant lint, typecheck, test, and production-build scripts that actually exist.
- For web UI changes, start the app and verify the real flow in Desktop's Browser pane. Use the macOS iOS Simulator pane for native iOS work when available.
- Browser and Simulator checks do not replace any explicitly required real-device test. Label untested device, Safari/PWA, external-service, or store behavior as unverified.
- Review the final diff in Desktop and use **Review code** as an additional check; it does not replace lint, tests, builds, visual verification, or Codex review.
- Report only: commands/checks run, passed, failed, warnings, and unverified items.

## Scope control

- Do not push, deploy, publish, rotate credentials, alter production data, or submit to an app store without explicit authorization.
- Do not add libraries until the existing stack and platform APIs have been checked.
- Do not place real guest data, access tokens, secrets, or personal links in source control, fixtures, screenshots, logs, or Markdown.

<!--
Why this file is short:
Anthropic recommends keeping CLAUDE.md concise and limited to broadly applicable commands, workflow rules, architectural decisions, and non-obvious constraints. Detailed product, API, and deployment knowledge remains in linked project docs; path-specific concerns live in .claude/rules/. Review this file after major changes and confirm at the start of the Desktop session that Claude recognizes these instructions.

Official Anthropic sources only:
- https://code.claude.com/docs/en/best-practices
- https://code.claude.com/docs/en/memory
- https://code.claude.com/docs/en/claude-directory
- https://code.claude.com/docs/en/desktop
- https://code.claude.com/docs/en/tools-reference
- https://code.claude.com/docs/en/agent-sdk/user-input
- https://academy.claude.com/
-->
