# PROJECT BRIEF — Sicilia27

**Estado:** borrador para revisión.  
**Propietario del producto:** Nacho.  
**Evento:** décimo aniversario de Mariana & Lukas en Sicilia, 28–30 de mayo de 2027.  
**Audiencia:** 65 invitados identificados.

## Resumen del proyecto

Sicilia27 es una aplicación privada y bilingüe que acompaña a los invitados del décimo aniversario de Mariana y Lukas en Sicilia. Primero recibe y valida el RSVP personalizado para los tres días; después se convierte en el hub móvil del evento con el RSVP confirmado, programa, información de viaje y, durante la celebración principal, carga moderada de fotos para un álbum colectivo.

## Qué hay hoy

El repositorio contiene un prototipo móvil en React 19, TypeScript, Vite, Tailwind y Vite PWA. Incluye una animación de entrada, el recorrido visual del RSVP, datos de invitados y eventos de demostración, un buscador ficticio de canciones, confirmación con pase/QR ficticio, guía de destino e instalación PWA.

La documentación previa indica que el prototipo llegó a compilar, pero Claude debe verificar en Plan Mode el `package.json`, el lockfile y los scripts reales antes de afirmar qué gestor, lint, typecheck, tests o build funcionan. No se considera demostrado que `npm run lint` equivalga a una comprobación TypeScript.

Independientemente de esa verificación, el prototipo presenta estos problemas funcionales conocidos:

- todo el estado vive en memoria;
- no existe persistencia, backend ni autenticación real;
- los invitados y tokens están dentro del cliente;
- un token inválido termina abriendo el primer perfil;
- se acepta coincidencia parcial por nombre;
- la asistencia viene preseleccionada;
- Spotify, QR, WhatsApp y confirmación son simulaciones;
- el RSVP enviado puede volver a editarse o reiniciarse;
- no existen Hub final, panel de control ni carga/moderación real de fotos.

`design.md` debe ignorarse incluso si aparece en una copia o historial del repositorio. Fue eliminado por el propietario y no constituye una fuente de requisitos.

## Qué hay que construir

Una experiencia móvil terminada, segura y operable que:

1. reconozca al invitado mediante un token personal, aplique nombre e idioma y evite datos duplicados o incompletos;
2. recoja el RSVP exacto de cada uno de los tres días, incluido el +1 por día;
3. guarde borradores, confirme una sola respuesta y bloquee su edición posterior;
4. muestre un Hub útil hasta y durante el evento;
5. permita sugerir hasta tres canciones buscando el catálogo real de Spotify;
6. permita subir fotos el Día 2 tras escanear un QR, sin mostrarlas hasta moderación;
7. ofrezca un panel privado ligero para envíos, estados, totales, exportación y moderación;
8. se publique como iOS y Android, conservando una PWA completa como alternativa.

## Objetivos de producto

- Hacer que una persona invitada —incluidas personas mayores— complete el RSVP sin ayuda.
- Tener una única fuente confiable para asistencia por día, +1, restricciones, shuttle, canciones y mensajes.
- Dar utilidad recurrente entre noviembre de 2026 y mayo de 2027, no ser una invitación estática.
- Evitar que la app nativa sea percibida por Apple como un simple sitio empaquetado.
- Mantener la operación razonable para una sola persona asistida por Claude/Codex, sin un CMS general.

## Plataformas y distribución

**CONFIRMADO:** móvil únicamente; español e inglés estadounidense; dominio `sicilia2027.com`; si es PWA, enlace propuesto `rsvp.sicilia2027.com`.

**RECOMENDADO:** conservar React/Vite y añadir Capacitor para generar iOS y Android desde la misma base, manteniendo la PWA. Para iOS, solicitar distribución *Unlisted* con enlace directo y mantener el token como control interno; para Android, listado normal pero contenido bloqueado por token.

La recomendación no garantiza aprobación. Apple exige que una app ofrezca utilidad, contenido e interfaz superiores a un sitio reempaquetado, y una app *Unlisted* igualmente debe pasar App Review. Apple indica además que cualquiera con el enlace *Unlisted* puede descargarla, por lo que el control de acceso dentro de la app sigue siendo necesario.

## Alcance funcional confirmado

### Acceso

- Un token opaco por invitación, incluso cuando exista +1.
- Perfil inicial: nombre, idioma, teléfono y permiso de +1; la ciudad puede existir, pero no afecta la experiencia.
- El idioma viene determinado por el token; el inglés será adaptación natural a EE. UU., no traducción literal.
- En web, el enlace personalizado abre el RSVP; en nativo, el mismo enlace debe abrir la app si está instalada o explicar descarga + código personal.
- El dispositivo recuerda el acceso.

### RSVP

- Cada día exige dos decisiones separadas cuando corresponde: asistencia del titular y asistencia de su +1.
- El +1 no puede asistir sin el titular.
- Nombre del +1 y restricciones alimentarias son opcionales y separados de los del titular.
- Shuttle únicamente para el Día 3.
- Canciones y mensaje opcionales; máximo tres canciones.
- Revisión editable antes de confirmar; confirmación final bloqueada.
- “Mi RSVP” muestra únicamente días confirmados y si asistirá solo o con +1.
- “Agregar al calendario” incluye únicamente los eventos confirmados.
- Rechazar los tres días activa una doble confirmación de cancelación, notifica al organizador y revoca el acceso al Hub.

### Hub

- Navegación estable: Inicio/Home, RSVP, Programa/Itinerario y Travel.
- El RSVP enviado se abre directamente en Home en visitas posteriores.
- Programa reutiliza la información del evento en una redacción condensada, sin controles de asistencia.
- Travel tendrá Noto, Sicilia, Europa y logística/viaje; combinará contenido editorial, enlaces externos y material de la agencia.
- El contenido será editable fuera de los componentes y versionado en español e inglés estadounidense.

### Fotos

- Solo para el evento principal del Día 2 y desbloqueado mediante QR en las mesas.
- Antes del desbloqueo no aparece como pestaña o función disponible.
- Solo fotos: tomar o elegir de galería; no video.
- Máximo 50 fotos por token y 10 por lote; cada archivo final debe pesar como máximo 3 MB.
- Archivos de hasta 3 MB conservan sus píxeles; archivos mayores se optimizan solo hasta quedar por debajo del límite, conservando dimensiones cuando sea viable.
- Guardar autor; aceptar un consentimiento breve en la primera subida.
- Nadie ve fotos pendientes. El panel privado permite ampliar, aprobar o rechazar.
- La galería aprobada y las descargas pertenecen a una fase final.

### Panel privado “Event Control Center”

- Invitaciones: nombre, teléfono, idioma, +1, enlace/token, acción de WhatsApp y estado manual de envío.
- Estados: pendiente de envío, enviado, abierto, en progreso, confirmado o cancelado, con fechas cuando existan.
- RSVP: totales por día, acompañantes, restricciones, shuttle Día 3, canciones y mensajes.
- Fotos: miniaturas, ampliación, autor, aprobar y rechazar.
- Datos: exportación a Google Sheets/CSV; la base de datos es la fuente operativa, no la hoja.

## Principios de experiencia y estética

- Intuitiva para personas mayores.
- Sofisticada sin pretensión; elegante y cálida.
- Claramente una app, no un PDF interactivo.
- Paleta contenida y jerarquía tipográfica legible.
- Evitar clichés de pizzería italiana, romanticismo excesivo, estética genérica de boda y señales de contenido generado por IA.
- Mantener vida mediante movimiento con propósito, microinteracciones y estados claros, respetando `prefers-reduced-motion`.
- La animación de bienvenida conserva el concepto, no su ejecución actual.
- La estructura funcional del RSVP registra la intención actualmente confirmada por Nacho; no debe cambiarse silenciosamente, pero Claude debe señalar incongruencias antes de implementarla. El diseño visual actual no está aprobado.

## Fuera de alcance inicial

- Backend/CMS general para editar contenidos.
- Edición del RSVP después de confirmar.
- Automatización inicial de WhatsApp.
- Reproducción musical, creación de playlists o acceso a canciones sugeridas por otros invitados.
- Video, comentarios, reacciones o galería pública sin moderación.
- QR/pase con validez de acceso.
- Analítica publicitaria.
- Ordenador/tablet como experiencia de destino; la interfaz está diseñada para móvil y solo debe mantenerse utilizable en pantallas no prioritarias.

## Criterios de éxito

- Un token válido abre exactamente una invitación; uno inválido no filtra ningún dato.
- No puede confirmarse un RSVP con un día sin responder ni un +1 incoherente.
- Reintentar o recargar no duplica la confirmación.
- Al volver, un borrador continúa y un confirmado abre Home.
- Panel y exportación concuerdan con los datos guardados.
- Spotify devuelve versiones reales con carátula y enlace de atribución.
- Carga de fotos respeta tipo, lote, cantidad, peso, autor y moderación.
- UI probada en tamaños móviles, con controles accesibles y alternativa a movimiento.
- Los scripts reales de lint, tipos, pruebas y build identificados en el proyecto pasan antes de cada release.
- Claude verifica el flujo web en el Browser pane de Desktop; iOS nativo en Simulator cuando corresponda; y marca explícitamente toda prueba pendiente en dispositivo real.

## TBD que bloquean contenido, no arquitectura

- Lugar del Día 1.
- Horas y copy definitivos.
- Fecha/hora límite exacta del RSVP.
- Email organizador.
- Contenido del Home pre-evento y material de Travel.
- Destino y duración final de la galería.
- Dominio del panel y proveedor de correo/notificaciones.

## Lógica de este brief

Este documento define el “qué” y los límites, pero no repite esquemas ni procedimientos técnicos. Esa separación permite actualizar contenido o arquitectura sin alterar silenciosamente el producto confirmado. Las recomendaciones de distribución se basan en requisitos oficiales vigentes; son estrategia, no promesa de aprobación.

### Fuentes oficiales

- [Capacitor — documentación general](https://capacitorjs.com/docs)
- [Capacitor — Progressive Web Apps](https://capacitorjs.com/docs/web/progressive-web-apps)
- [Apple — App Review Guidelines, 4.2 Minimum Functionality](https://developer.apple.com/app-store/review/guidelines/#minimum-functionality)
- [Apple — Unlisted App Distribution](https://developer.apple.com/support/unlisted-app-distribution/)
- [Apple — App Review Guidelines, 1.2 User-Generated Content](https://developer.apple.com/app-store/review/guidelines/#user-generated-content)
- [W3C — WCAG 2.2](https://www.w3.org/TR/WCAG22/)
- [Anthropic — Claude Code Desktop](https://code.claude.com/docs/en/desktop)
