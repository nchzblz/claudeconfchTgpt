---
paths:
  - "apps/**/*.{ts,tsx,json}"
  - "packages/**/*.{ts,tsx,json,sql}"
  - "supabase/**/*"
  - "src/**/*.{ts,tsx}"
  - "*.env*"
---

# Security and personal-data rules

- A guest token is a credential. Never print, commit, log, expose in analytics, or place a real token in a test fixture.
- Remove token query parameters from the visible URL after safe exchange/storage.
- Validate guest authorization server-side on every read or write; hiding UI is not authorization.
- Guest clients may use only public/publishable configuration. Secret/service keys and the Spotify client secret remain server-side.
- Enforce RSVP uniqueness, lock-after-submit, song limits, photo limits, MIME/file validation, and moderation state on the server as well as in the UI.
- Store uploaded photos privately until approved. Signed access must be short-lived and scoped.
- Collect the minimum personal data in the brief; support the documented deletion-request route.
- Never weaken row-level security or admin authentication merely to make a test pass.

<!--
Logic: security rules are separated because they apply to several technical surfaces and are easy to lose inside product prose. The path scope includes client, server, SQL and environment configuration.

Official Anthropic sources only for this Claude configuration pattern:
- https://code.claude.com/docs/en/memory#organize-rules-with-clauderules
- https://code.claude.com/docs/en/memory#path-specific-rules
-->

