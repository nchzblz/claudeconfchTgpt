---
paths:
  - "apps/**/*.{ts,tsx}"
  - "packages/**/*.{ts,tsx,sql}"
  - "src/**/*.{ts,tsx}"
  - "tests/**/*"
---

# Verification rules

- Add or update tests for every changed business rule.
- Prefer a focused test during iteration, then run the full relevant suite before handoff.
- Before running commands, inspect the project's actual package manager, lockfile and scripts. Never assume npm, script names, or that lint performs typechecking.
- Run the real lint, typecheck, test and production-build commands that exist. If a required check is absent, ask before adding or changing tooling.
- Execute checks yourself inside Claude Desktop's Code session; do not instruct Nacho to use macOS Terminal.
- For web UI work, start the project and verify the affected flow in Desktop's Browser pane against the approved target or acceptance criteria.
- For native iOS work, use Desktop's iOS Simulator pane when available. State explicitly what still requires a physical iPhone, Safari/PWA behavior, external service, or store review.
- Review the final Desktop Diff and use Review code as an additional signal, never as a substitute for executable or visual verification.
- Test at minimum: invalid token, reload/resume, each day +1 rule, all-days-declined cancellation, double submit, confirmed lock, three-song limit, Day 3 shuttle, QR photo unlock, batch/count/size limits, moderation visibility, Spanish and US English.
- A passing build does not prove the flow. State what was not exercised on a real device or external service.

<!--
Logic: Anthropic recommends giving Claude a machine-readable pass/fail loop and visual verification for UI. This conditional file makes that expectation available whenever implementation or tests are touched.

Official Anthropic sources only:
- https://code.claude.com/docs/en/best-practices#give-claude-a-way-to-verify-its-work
- https://code.claude.com/docs/en/best-practices#explore-first-then-plan-then-code
- https://code.claude.com/docs/en/desktop
-->
