---
paths:
  - "apps/**/*.{ts,tsx,css}"
  - "packages/**/*.{ts,tsx,css,json}"
  - "src/**/*.{ts,tsx,css}"
---

# Frontend and content rules

- Treat the experience as portrait-first mobile UI; it must still remain usable if a PWA is opened in landscape.
- Keep event copy and editable facts outside React components in `content/es` and `content/en-US` equivalents.
- English copy is US adaptation, not literal translation.
- Model unanswered choices explicitly; booleans must not make an unanswered RSVP look confirmed.
- Use large, plainly labeled controls and visible validation. Never rely on color alone.
- Respect `prefers-reduced-motion`; motion must guide or explain state, not delay task completion.
- Do not reuse the prototype's aesthetic as a mandate. Preserve only the confirmed RSVP structure and approved assets.
- Never fake Spotify results, QR validity, submission success, persistence, notifications, or offline writes.

<!--
Logic: this rule is path-scoped because it matters only while Claude is reading frontend or content files. Anthropic documents YAML `paths` frontmatter for conditional rules so unrelated work does not carry this context.

Official Anthropic sources only:
- https://code.claude.com/docs/en/memory#path-specific-rules
- https://code.claude.com/docs/en/best-practices
-->

